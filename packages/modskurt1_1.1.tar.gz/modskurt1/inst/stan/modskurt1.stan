functions {

 real lmodskurt(real x, real H, real m, real s, real r, real d, real p) {
   	real base = r * exp(((x - m) / (r * s) - d) / p) +
   	    (1 - r) * exp(- ((x - m) / ((1 - r) * s) + d) / p) -
   	    exp(-d / p) + 1;
    	base = fmin(fmax(base, 1e-6), 1e6);
    	return log(H) - p * log(base);
  }

 // Core likelihood functions (zero-inflated and standard)
 // ZI-linkage suffixes: the excess-zero probability pi is linked to the mean (l: g0 + g1*mu), the
 // log-mean (.mu: g0 + g1*log mu), or the mean scaled by 1/H (ll). The l = mean and .mu = log-mean
 // meanings follow Martins et al. (2024, PNAS).
 real zinb_lpmf(int y, real lmu, real phi, real gamma0) {
    real pi = inv_logit(gamma0);
    return y == 0 ?
      log_sum_exp(bernoulli_lpmf(1 | pi), bernoulli_lpmf(0 | pi) + neg_binomial_2_log_lpmf(0 | lmu, phi)) :
      bernoulli_lpmf(0 | pi) + neg_binomial_2_log_lpmf(y | lmu, phi);
  }

  real zinbl_lpmf(int y, real lmu, real phi, real gamma0, real gamma1) {
  real lmu_clipped = fmin(fmax(lmu, -20), 20);
  real mu = fmin(fmax(exp(lmu_clipped), 1e-6), 1 - 1e-6);
  real pi = inv_logit(gamma0 + gamma1 * mu);
  return y == 0 ?
    log_sum_exp(bernoulli_lpmf(1 | pi), bernoulli_lpmf(0 | pi) + neg_binomial_2_log_lpmf(0 | lmu, phi)) :
    bernoulli_lpmf(0 | pi) + neg_binomial_2_log_lpmf(y | lmu, phi);
  }

  // This is the same as zinbll in Marquet et al PNAS 2024 paper (uses log(mu))
  real zinbl_mu_lpmf(int y, real lmu, real phi, real gamma0, real gamma1) {
  real lmu_clipped = fmin(fmax(lmu, -20), 20);
  real pi = inv_logit(gamma0 + gamma1 * lmu_clipped);
  return y == 0 ?
    log_sum_exp(bernoulli_lpmf(1 | pi), bernoulli_lpmf(0 | pi) + neg_binomial_2_log_lpmf(0 | lmu, phi)) :
    bernoulli_lpmf(0 | pi) + neg_binomial_2_log_lpmf(y | lmu, phi);
  }

   real zip_lpmf(int y, real lmu, real gamma0) {
   real pi = inv_logit(gamma0);
   return y == 0 ?
   log_sum_exp(bernoulli_lpmf(1 | pi), bernoulli_lpmf(0 | pi) + poisson_log_lpmf(0 | lmu)) :
   bernoulli_lpmf(0 | pi) + poisson_log_lpmf(y | lmu);
  }

  real zipl_lpmf(int y, real lmu, real gamma0, real gamma1) {
  real lmu_clipped = fmin(fmax(lmu, -20), 20);
  real mu = fmin(fmax(exp(lmu_clipped), 1e-6), 1 - 1e-6);
  real pi = inv_logit(gamma0 + gamma1 * mu);
  return y == 0 ?
    log_sum_exp(bernoulli_lpmf(1 | pi), bernoulli_lpmf(0 | pi) + poisson_log_lpmf(0 | lmu)) :
    bernoulli_lpmf(0 | pi) + poisson_log_lpmf(y | lmu);
  }

  // This is the same as zipll in Marquet et al PNAS 2024 paper (uses log(mu))
  real zipl_mu_lpmf(int y, real lmu, real gamma0, real gamma1) {
  real lmu_clipped = fmin(fmax(lmu, -20), 20);
  real pi = inv_logit(gamma0 + gamma1 * lmu_clipped);
  return y == 0 ?
    log_sum_exp(bernoulli_lpmf(1 | pi), bernoulli_lpmf(0 | pi) + poisson_log_lpmf(0 | lmu)) :
    bernoulli_lpmf(0 | pi) + poisson_log_lpmf(y | lmu);
  }

  // pi is defined here following the zinbll definition in the original modskurt package (-gamma1/H * mu + gamma0)
  real zinbll_lpmf(int y, real lmu, real phi, real gamma0, real gamma1, real H) {
  real lmu_clipped = fmin(fmax(lmu, -20), 20);
  real mu = fmin(fmax(exp(lmu_clipped), 1e-6), 1 - 1e-6);
  real pi = inv_logit(-gamma1/H * mu + gamma0);
  return y == 0 ?
    log_sum_exp(bernoulli_lpmf(1 | pi), bernoulli_lpmf(0 | pi) + neg_binomial_2_log_lpmf(0 | lmu, phi)) :
    bernoulli_lpmf(0 | pi) + neg_binomial_2_log_lpmf(y | lmu, phi);
  }

  // pi is defined here following the zinbll definition in the original modskurt package (-gamma1/H * mu + gamma0)
  real zipll_lpmf(int y, real lmu, real gamma0, real gamma1, real H) {
  real lmu_clipped = fmin(fmax(lmu, -20), 20);
  real mu = fmin(fmax(exp(lmu_clipped), 1e-6), 1 - 1e-6);
  real pi = inv_logit(-gamma1/H * mu + gamma0);
  return y == 0 ?
    log_sum_exp(bernoulli_lpmf(1 | pi), bernoulli_lpmf(0 | pi) + poisson_log_lpmf(0 | lmu)) :
    bernoulli_lpmf(0 | pi) + poisson_log_lpmf(y | lmu);
  }

  real gaussian_lpdf(real y, real mu, real sigma) {
    return normal_lpdf(y | mu, sigma);
  }

  // Continuous models
  real tab_lpdf(real y, real lmu, real r, real d, real p, real k) {
  real mu = fmin(fmax(exp(lmu), 1e-6), 1 - 1e-6);
  real k_safe = fmin(k, 5);
  real alpha = mu * k_safe;
  real beta = (1 - mu) * k_safe;
  real y_safe = fmin(fmax(y, 1e-6), 1 - 1e-6);
  if (alpha > 0 && beta > 0)
    return beta_lpdf(y_safe | alpha, beta);
  else {
    reject("Invalid alpha or beta in tab_lpdf: ", alpha, beta);
  }
}

  real zitab_lpdf(real y, real lmu, real r, real d, real p,
                  real gamma0, real gamma1, real delta, real k) {
  real mu = fmin(fmax(exp(lmu), 1e-6), 1 - 1e-6);
  real lmu_clipped = fmin(fmax(lmu, -20), 20);
  real k_safe = fmin(k, 5);
  real alpha = mu * k_safe;
  real beta = (1 - mu) * k_safe;
  real pi = inv_logit(gamma0 + gamma1 * lmu_clipped);
  real y_safe = fmin(fmax(y, 1e-6), 1 - 1e-6);
  if (alpha <= 0 || beta <= 0)
    reject("Invalid alpha or beta in zitab: ", alpha, beta);
  if (y_safe <= delta)
    return log_sum_exp(log(pi), log1m(pi) + beta_lpdf(1e-6 | alpha, beta));
  else
    return log1m(pi) + beta_lpdf(y_safe | alpha, beta);
 }

  // Zero-inflated gamma
  // For y=0: structural zero with probability pi
  // For y>0: continuous gamma distribution with probability (1-pi)
  // NOTE: Previously used log_sum_exp formula for y=0 which incorrectly coupled
  // mu estimation with zero-fitting via gamma_lpdf(1e-6). Now consistent with ziln.
  real zig_lpdf(real y, real alpha, real beta, real gamma0) {
    real pi = inv_logit(gamma0);
    return y == 0 ?
      log(pi) :
      log1m(pi) + gamma_lpdf(y | alpha, beta);
  }

  // pi is defined here as in functions zinbll and zinpll in Marquet et al PNAS 2024 paper (uses log(mu))
  real zigl_mu_lpdf(real y, real lmu, real alpha, real beta, real gamma0, real gamma1) {
  real lmu_clipped = fmin(fmax(lmu, -20), 20);
  real logit_pi = gamma0 + gamma1 * lmu_clipped;  // pass logit-scale, not pi
  return zig_lpdf(y | alpha, beta, logit_pi);
  }

  real zigl_lpdf(real y, real lmu, real alpha, real beta, real gamma0, real gamma1) {
  real lmu_clipped = fmin(fmax(lmu, -20), 20);
  real mu = fmin(fmax(exp(lmu_clipped), 1e-6), 1 - 1e-6);
  real logit_pi = gamma0 + gamma1 * mu;  // pass logit-scale, not pi
  return zig_lpdf(y | alpha, beta, logit_pi);
  }

  // pi is defined here following the zinbll definition in the original modskurt package (-gamma1/H * mu + gamma0)
  real zigll_lpdf(real y, real lmu, real alpha, real beta, real gamma0, real gamma1, real H) {
  real lmu_clipped = fmin(fmax(lmu, -20), 20);
  real mu = fmin(fmax(exp(lmu_clipped), 1e-6), 1 - 1e-6);
  real logit_pi = -gamma1/H * mu + gamma0;  // pass logit-scale, not pi
  return zig_lpdf(y | alpha, beta, logit_pi);
  }

  // Zero-inflated log-normal distributions for density data
  // Parameterized so that median(Y|Y>0) = exp(lmu), E[Y|Y>0] = exp(lmu + sigma^2/2)
  real ziln_lpdf(real y, real lmu, real sigma, real gamma0) {
    real pi = inv_logit(gamma0);
    real lmu_clipped = fmin(fmax(lmu, -20), 20);
    real sigma_safe = fmin(fmax(sigma, 1e-4), 10);
    return y == 0 ?
      log(pi) :
      log1m(pi) + lognormal_lpdf(y | lmu_clipped, sigma_safe);
  }

  // pi linked to log(mu) - same style as zinbl_mu
  real zilnl_mu_lpdf(real y, real lmu, real sigma, real gamma0, real gamma1) {
    real lmu_clipped = fmin(fmax(lmu, -20), 20);
    real logit_pi = gamma0 + gamma1 * lmu_clipped;
    return ziln_lpdf(y | lmu, sigma, logit_pi);
  }

  // pi linked to mu - same style as zinbl
  real zilnl_lpdf(real y, real lmu, real sigma, real gamma0, real gamma1) {
    real lmu_clipped = fmin(fmax(lmu, -20), 20);
    real mu = fmin(fmax(exp(lmu_clipped), 1e-6), 1e6);
    real logit_pi = gamma0 + gamma1 * mu;
    return ziln_lpdf(y | lmu, sigma, logit_pi);
  }

  // pi following original modskurt package style (-gamma1/H * mu + gamma0)
  real zilnll_lpdf(real y, real lmu, real sigma, real gamma0, real gamma1, real H) {
    real lmu_clipped = fmin(fmax(lmu, -20), 20);
    real mu = fmin(fmax(exp(lmu_clipped), 1e-6), 1e6);
    real logit_pi = -gamma1/H * mu + gamma0;
    return ziln_lpdf(y | lmu, sigma, logit_pi);
  }

}

data {

// Hyperparameters for priors
  vector[2] hp_H;
  vector[2] hp_m;
  vector[2] hp_s;
  vector[2] hp_r;
  vector[2] hp_d;
  real hp_kap;

  vector[2] hp_gamma0;
  real hp_gamma1;

  int<lower=1> N;
  vector[N] x;
  array[N] int<lower=0> y_int;
  vector[N] y_cont;
  real<lower=0> max_y;
  real range_x;
  real min_x;
  int<lower=1, upper=22> dist_code;

  int<lower=0, upper=1> use_r;
  int<lower=0, upper=1> use_d;
  int<lower=0, upper=1> use_p;
  real<lower=0, upper=1> fix_r;
  real<lower=0> fix_d;
  real<lower=0, upper=1> fix_p;
  real<lower=0> delta;
}

parameters {
  real<lower=0, upper=1> H_raw;
  real<lower=0, upper=1> m_raw;
  real log_s_raw;
  real<lower=0, upper=1> zr_raw;
  real log_d_raw;
  real<lower=0, upper=1> zp_raw;
  real<lower=1e-4> k;
  real gamma0;
  real gamma1;
  real<lower=1e-4> sigma;
}

transformed parameters {
  real H = H_raw * max_y;
  real m = m_raw * range_x + min_x;
  real s = exp(log_s_raw + log(range_x));
  real r = use_r == 1 ? zr_raw : fix_r;
  real d = use_d == 1 ? exp(log_d_raw) : fix_d;
  real p = use_p == 1 ? zp_raw * 1.95 + 0.05 : fix_p;
  real phi = 1 / square(fmin(fmax(k, 0.1), 5));
}

model {
  // Priors
  H_raw ~ beta(hp_H[1], hp_H[2]);
  m_raw ~ beta(hp_m[1], hp_m[2]);
  log_s_raw ~ normal(hp_s[1], hp_s[2]);
  zr_raw ~ beta(hp_r[1], hp_r[2]);
  log_d_raw ~ normal(hp_d[1], hp_d[2]);
  k ~ exponential(hp_kap);
  gamma0 ~ normal(hp_gamma0[1], hp_gamma0[2]);
  gamma1 ~ normal(hp_gamma1, 1);

  real lmu;
  sigma ~ normal(0, 2);

  for (n in 1:N) {
	lmu = lmodskurt(x[n], H, m, s, r, d, p);
	lmu = fmin(fmax(lmu, -20), 20);
    real mu = exp(lmu);
    real k_safe = fmin(fmax(k, 1e-2), 5);
    // Beta distribution params (for tab, zitab): E[Y] = alpha/(alpha+beta) = mu
    real alpha = mu * k_safe;
    real beta = (1 - mu) * k_safe;
    // Gamma distribution params (for zig*): E[Y|Y>0] = alpha_g/beta_g = mu
    real alpha_g = mu * k_safe;
    real beta_g = k_safe;

    if (dist_code == 1) target += zinb_lpmf(y_int[n] | lmu, phi, gamma0);
    else if (dist_code == 2) target += zinbl_lpmf(y_int[n] | lmu, phi, gamma0, gamma1);
    else if (dist_code == 3) target += zinbl_mu_lpmf(y_int[n] | lmu, phi, gamma0, gamma1);
    else if (dist_code == 4) target += neg_binomial_2_log_lpmf(y_int[n] | lmu, phi);
    else if (dist_code == 5) target += poisson_log_lpmf(y_int[n] | lmu);
    else if (dist_code == 6) {
      int y_bin = y_int[n] == 0 ? 0 : 1;
      target += bernoulli_logit_lpmf(y_bin | lmu);
    }
    else if (dist_code == 7)
      target += tab_lpdf(y_cont[n] | lmu, r, d, p, k);
	else if (dist_code == 8)
      target += zitab_lpdf(y_cont[n] | lmu, r, d, p, gamma0, gamma1, delta, k);
	else if (dist_code == 9) target += zig_lpdf(y_cont[n] | alpha_g, beta_g, gamma0);
    else if (dist_code == 10) target += zigl_mu_lpdf(y_cont[n] | lmu, alpha_g, beta_g, gamma0, gamma1);
    else if (dist_code == 11) target += zigl_lpdf(y_cont[n] | lmu, alpha_g, beta_g, gamma0, gamma1);
    else if (dist_code == 12) target += zip_lpmf(y_int[n] | lmu, gamma0);
    else if (dist_code == 13) target += zipl_lpmf(y_int[n] | lmu, gamma0, gamma1);
    else if (dist_code == 14) target += zipl_mu_lpmf(y_int[n] | lmu, gamma0, gamma1);
    else if (dist_code == 15) target += zinbll_lpmf(y_int[n] | lmu, phi, gamma0, gamma1, H);
    else if (dist_code == 16) target += zipll_lpmf(y_int[n] | lmu, gamma0, gamma1, H);
    else if (dist_code == 17) target += normal_lpdf(y_cont[n] | lmu, sigma);
    else if (dist_code == 18) target += zigll_lpdf(y_cont[n] | lmu, alpha_g, beta_g, gamma0, gamma1, H);
    // Zero-inflated log-normal distributions (19-22)
    else if (dist_code == 19) target += ziln_lpdf(y_cont[n] | lmu, sigma, gamma0);
    else if (dist_code == 20) target += zilnl_mu_lpdf(y_cont[n] | lmu, sigma, gamma0, gamma1);
    else if (dist_code == 21) target += zilnl_lpdf(y_cont[n] | lmu, sigma, gamma0, gamma1);
    else if (dist_code == 22) target += zilnll_lpdf(y_cont[n] | lmu, sigma, gamma0, gamma1, H);
  }
}

generated quantities {
  vector[N] log_lik;
  vector[N] y_rep;
  real lmu;

  for (n in 1:N) {
	lmu = lmodskurt(x[n], H, m, s, r, d, p);
	lmu = fmin(fmax(lmu, -20), 20);
    real mu = fmin(fmax(exp(lmu), 1e-6), 1 - 1e-6);
    real k_safe = fmin(k, 5);
    // Beta distribution params (for tab, zitab): E[Y] = alpha/(alpha+beta) = mu
    real alpha = mu * k_safe;
    real beta = (1 - mu) * k_safe;
    // Gamma distribution params (for zig*): E[Y|Y>0] = alpha_g/beta_g = mu
    real alpha_g = mu * k_safe;
    real beta_g = k_safe;

    if (dist_code == 1) {
      log_lik[n] = zinb_lpmf(y_int[n] | lmu, phi, gamma0);
      y_rep[n] = bernoulli_rng(inv_logit(gamma0)) == 1 ? 0 : neg_binomial_2_log_rng(lmu, phi);
    } else if (dist_code == 2) {
      log_lik[n] = zinbl_lpmf(y_int[n] | lmu, phi, gamma0, gamma1);
      y_rep[n] = bernoulli_rng(inv_logit(gamma0 + gamma1 * mu)) == 1 ? 0 : neg_binomial_2_log_rng(lmu, phi);
    } else if (dist_code == 3) {
      log_lik[n] = zinbl_mu_lpmf(y_int[n] | lmu, phi, gamma0, gamma1);
      y_rep[n] = bernoulli_rng(inv_logit(gamma0 + gamma1 * lmu)) == 1 ? 0 : neg_binomial_2_log_rng(lmu, phi);
    } else if (dist_code == 4) {
      log_lik[n] = neg_binomial_2_log_lpmf(y_int[n] | lmu, phi);
      y_rep[n] = neg_binomial_2_log_rng(lmu, phi);
    } else if (dist_code == 5) {
      log_lik[n] = poisson_log_lpmf(y_int[n] | lmu);
      y_rep[n] = poisson_log_rng(lmu);
    } else if (dist_code == 6) {
      log_lik[n] = bernoulli_logit_lpmf(y_int[n] == 0 ? 0 : 1 | lmu);
      y_rep[n] = bernoulli_logit_rng(lmu);
    } else if (dist_code == 7) {
	  log_lik[n] = tab_lpdf(y_cont[n] | lmu, r, d, p, k);
      y_rep[n] = beta_rng(alpha, beta);
    } else if (dist_code == 8) {
      log_lik[n] = zitab_lpdf(y_cont[n] | lmu, r, d, p, gamma0, gamma1, delta, k);
      y_rep[n] = bernoulli_rng(inv_logit(gamma0 + gamma1 * lmu)) == 1 ? 0 : beta_rng(alpha, beta);
	} else if (dist_code == 9) {
      log_lik[n] = zig_lpdf(y_cont[n] | alpha_g, beta_g, gamma0);
      y_rep[n] = bernoulli_rng(inv_logit(gamma0)) == 1 ? 0 : gamma_rng(alpha_g, beta_g);
    } else if (dist_code == 10) {
      log_lik[n] = zigl_mu_lpdf(y_cont[n] | lmu, alpha_g, beta_g, gamma0, gamma1);
      y_rep[n] = bernoulli_rng(inv_logit(gamma0 + gamma1 * lmu)) == 1 ? 0 : gamma_rng(alpha_g, beta_g);
    } else if (dist_code == 11) {
      log_lik[n] = zigl_lpdf(y_cont[n] | lmu, alpha_g, beta_g, gamma0, gamma1);
      y_rep[n] = bernoulli_rng(inv_logit(gamma0 + gamma1 * mu)) == 1 ? 0 : gamma_rng(alpha_g, beta_g);
    } else if (dist_code == 12) {
      log_lik[n] = zip_lpmf(y_int[n] | lmu, gamma0);
      y_rep[n] = bernoulli_rng(inv_logit(gamma0)) == 1 ? 0 : poisson_log_rng(lmu);
    } else if (dist_code == 13) {
      log_lik[n] = zipl_lpmf(y_int[n] | lmu, gamma0, gamma1);
      y_rep[n] = bernoulli_rng(inv_logit(gamma0 + gamma1 * mu)) == 1 ? 0 : poisson_log_rng(lmu);
    } else if (dist_code == 14) {
      log_lik[n] = zipl_mu_lpmf(y_int[n] | lmu, gamma0, gamma1);
      y_rep[n] = bernoulli_rng(inv_logit(gamma0 + gamma1 * lmu)) == 1 ? 0 : poisson_log_rng(lmu);
    } else if (dist_code == 15) {
      log_lik[n] = zinbll_lpmf(y_int[n] | lmu, phi, gamma0, gamma1, H);
      y_rep[n] = bernoulli_rng(inv_logit(-gamma1/H * mu + gamma0)) == 1 ? 0 : neg_binomial_2_log_rng(lmu, phi);
    } else if (dist_code == 16) {
      log_lik[n] = zipll_lpmf(y_int[n] | lmu, gamma0, gamma1, H);
      y_rep[n] = bernoulli_rng(inv_logit(-gamma1/H * mu + gamma0)) == 1 ? 0 : poisson_log_rng(lmu);
    } else if (dist_code == 17) {
      log_lik[n] = normal_lpdf(y_cont[n] | lmu, sigma);
      y_rep[n] = normal_rng(lmu, sigma);
    } else if (dist_code == 18) {
      log_lik[n] = zigll_lpdf(y_cont[n] | lmu, alpha_g, beta_g, gamma0, gamma1, H);
      y_rep[n] = bernoulli_rng(inv_logit(-gamma1/H * mu + gamma0)) == 1 ? 0 : gamma_rng(alpha_g, beta_g);
    // Zero-inflated log-normal distributions (19-22)
    } else if (dist_code == 19) {
      log_lik[n] = ziln_lpdf(y_cont[n] | lmu, sigma, gamma0);
      y_rep[n] = bernoulli_rng(inv_logit(gamma0)) == 1 ? 0 : lognormal_rng(lmu, sigma);
    } else if (dist_code == 20) {
      log_lik[n] = zilnl_mu_lpdf(y_cont[n] | lmu, sigma, gamma0, gamma1);
      y_rep[n] = bernoulli_rng(inv_logit(gamma0 + gamma1 * lmu)) == 1 ? 0 : lognormal_rng(lmu, sigma);
    } else if (dist_code == 21) {
      log_lik[n] = zilnl_lpdf(y_cont[n] | lmu, sigma, gamma0, gamma1);
      y_rep[n] = bernoulli_rng(inv_logit(gamma0 + gamma1 * mu)) == 1 ? 0 : lognormal_rng(lmu, sigma);
    } else if (dist_code == 22) {
      log_lik[n] = zilnll_lpdf(y_cont[n] | lmu, sigma, gamma0, gamma1, H);
      y_rep[n] = bernoulli_rng(inv_logit(-gamma1/H * mu + gamma0)) == 1 ? 0 : lognormal_rng(lmu, sigma);
    }
  }
}
