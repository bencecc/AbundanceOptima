#' Compute Log-Likelihood, AIC, and AICc from Modskurt Fitted Model
#'
#' Extracts log-likelihood values from the fitted cmdstanr object and computes
#' AIC and AICc for model comparison. The number of parameters is determined
#' automatically based on the distribution and which shape parameters are estimated.
#'
#' @param cmdstanr.obj A fitted cmdstanr model object from \code{\link{modskurt_fit}}.
#' @param data_list A list of data (the spec object) used for fitting.
#' @param ... Additional arguments (currently unused).
#'
#' @return A data frame with one row containing:
#'   \item{log_lik}{Total log-likelihood (sum of pointwise log-likelihoods)}
#'   \item{AIC}{Akaike Information Criterion: -2 * log_lik + 2 * k}
#'   \item{AICc}{Corrected AIC for small samples:
#'     AIC + (2k(k+1))/(n-k-1)}
#'   \item{n_params}{Number of estimated parameters}
#'
#' @details
#' The base number of parameters is 3 (H_raw, m_raw, log_s_raw). Additional
#' parameters are counted based on:
#'
#' \itemize{
#'   \item Shape parameters: +1 for each of r, d, p if estimated (use_* = 1)
#'   \item Dispersion k: +1 for NB, Beta, and Gamma distributions (1-4, 7-11, 15, 18)
#'   \item gamma0: +1 for all zero-inflated distributions (1-3, 8-16, 18-22)
#'   \item gamma1: +1 for ZI distributions with linked pi (2-3, 8, 10-11, 13-16, 18, 20-22)
#'   \item sigma: +1 for Gaussian and log-normal distributions (17, 19-22)
#' }
#'
#' The pointwise log-likelihoods are extracted from the \code{log_lik} generated
#' quantity in the Stan model, then averaged across posterior draws and summed.
#'
#' @examples
#' \dontrun{
#' # Simulate data and fit model
#' sim <- modskurt_sim(N = 100, dist = "zinb", H = 15, m = 0.5, s = 0.1, seed = 42)
#' spec <- modskurt_spec(sim$x, sim$y, distribution = "zinb")
#' mod <- cmdstanr::cmdstan_model(modskurt_stan_path())
#' fit <- modskurt_fit(spec, mod = mod, chains = 2)
#'
#' # Compute AIC
#' aic_result <- modskurt_LL_AIC(fit, spec)
#' print(aic_result)
#' #>   log_lik      AIC     AICc n_params
#' #> 1  -245.3   506.6    508.1        8
#'
#' # Compare models with different distributions
#' spec_nb <- modskurt_spec(sim$x, sim$y, distribution = "nb")
#' fit_nb <- modskurt_fit(spec_nb, mod = mod, chains = 2)
#' aic_nb <- modskurt_LL_AIC(fit_nb, spec_nb)
#'
#' # Model with fewer parameters (fixed shape)
#' spec_simple <- modskurt_spec(sim$x, sim$y, distribution = "zinb",
#'                              use_r = 0, use_d = 0, use_p = 0)
#' fit_simple <- modskurt_fit(spec_simple, mod = mod, chains = 2)
#' aic_simple <- modskurt_LL_AIC(fit_simple, spec_simple)
#'
#' # Compare AICs
#' rbind(zinb = aic_result, nb = aic_nb, simple = aic_simple)
#' }
#'
#' @seealso \code{\link{modskurt_fit}}, \code{\link{modskurt_spec}}
#'
#' @export
modskurt_LL_AIC <- function(cmdstanr.obj, data_list, ...) {
	# Extract log-likelihood
	log_lik <- posterior::as_draws_matrix(cmdstanr.obj$draws("log_lik"))
	log_lik_pointwise <- apply(log_lik, 2, mean)
	log_lik_total <- sum(log_lik_pointwise)

	dist_code <- data_list$dist_code
	n_params <- 3  # H_raw, m_raw, log_s_raw

	# Optional shape parameters
	if (data_list$use_r == 1) n_params <- n_params + 1
	if (data_list$use_d == 1) n_params <- n_params + 1
	if (data_list$use_p == 1) n_params <- n_params + 1

	# Distribution-specific
	# k (dispersion): NB-based (1-4,15), Gamma-based (9-11,18), Beta-based (7-8)
	if (dist_code %in% c(1:4, 7:11, 15, 18)) {
		n_params <- n_params + 1  # k
	}
	# gamma0: all zero-inflated distributions
	if (dist_code %in% c(1:3, 8:16, 18:22)) {
		n_params <- n_params + 1  # gamma0
	}
	# gamma1: zero-inflated with linked pi (not simple zi like zinb, zig, zip, ziln)
	if (dist_code %in% c(2:3, 8, 10:11, 13:16, 18, 20:22)) {
		n_params <- n_params + 1  # gamma1
	}
	# sigma: gaussian and log-normal distributions
	if (dist_code %in% c(17, 19:22)) {
		n_params <- n_params + 1  # sigma
	}

	# AIC and AICc
	AIC <- -2 * log_lik_total + 2 * n_params
	AICc <- AIC + (2 * n_params * (n_params + 1)) / (data_list$N - n_params - 1)

	return(data.frame(
					log_lik = log_lik_total,
					AIC = AIC,
					AICc = AICc,
					n_params = n_params
			))
}
