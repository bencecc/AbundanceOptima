
#' Simulate Data from Modskurt Model
#'
#' Generates synthetic datasets using one of the 22 supported modskurt distributions.
#' The modskurt curve is a flexible asymmetric response function with parameters
#' controlling height (H), mode location (m), spread (s), asymmetry (r),
#' displacement (d), and kurtosis (p).
#'
#' @param N Number of observations to simulate. Default is 200.
#' @param x Optional numeric vector of predictor values. If NULL, generates
#'   uniformly distributed values on [0,1].
#' @param dist Character string specifying the distribution. One of:
#'   \itemize{
#'     \item Count distributions: "zinb", "zinbl", "zinbl.mu", "nb", "poisson",
#'           "zip", "zipl", "zipl.mu", "zinbll", "zipll", "gaussian"
#'     \item Proportion distributions: "tab", "zitab"
#'     \item Density distributions: "zig", "zigl.mu", "zigl", "zigll",
#'           "ziln", "zilnl.mu", "zilnl", "zilnll"
#'     \item Binary: "bern"
#'   }
#' @param H Peak height of the response curve. If NULL, drawn from Beta(2,3).
#' @param m Mode (x-value at peak). If NULL, drawn uniformly within x range.
#' @param s Spread/scale parameter. If NULL, drawn from exp(N(-2, 0.3)) * range(x).
#' @param r Asymmetry parameter in (0,1). If NULL, drawn from Beta(1.2, 1.2).
#' @param d Displacement parameter. If NULL, drawn from exp(N(0.5, 1)).
#' @param p Kurtosis parameter. If NULL, drawn from Beta(1.2, 1.2) * 1.95 + 0.05.
#' @param k Dispersion parameter for negative binomial, gamma, or beta distributions.
#'   If NULL, drawn from Exp(0.5).
#' @param delta Smoothing parameter for zero-inflated beta (zitab). Default is 0.01.
#' @param pi Base zero-inflation probability (not used directly, see gamma0/gamma1).
#' @param gamma0 Intercept for zero-inflation logit model. If NULL, drawn from N(0,1).
#' @param gamma1 Slope for zero-inflation logit model. If NULL, drawn from N(0,1).
#' @param sigma Standard deviation for log-normal distributions (ziln variants).
#'   If NULL, drawn from |N(1, 0.25)|.
#' @param seed Random seed for reproducibility. If NULL, uses system time.
#'
#' @return A list containing:
#'   \item{x}{Numeric vector of predictor values}
#'   \item{y}{Numeric vector of response values}
#'   \item{y_int}{Integer response (for count/binary data)}
#'   \item{y_cont}{Continuous response (for proportion/density data)}
#'   \item{dist_code}{Integer code for the distribution}
#'   \item{dist_name}{Character name of the distribution}
#'   \item{params}{List of true parameter values used in simulation}
#'
#' @details
#' The function generates data from a modskurt mean response curve combined with
#' various error distributions. Zero-inflated variants use a logit model for the
#' zero-inflation probability with different parameterizations:
#' \itemize{
#'   \item Constant: pi = logit^{-1}(gamma0) for zinb, zig, zip, ziln
#'   \item Linear in mu: pi = logit^{-1}(gamma0 + gamma1 * mu) for zinbl, zigl, zipl, zilnl
#'   \item Linear in log(mu): pi = logit^{-1}(gamma0 + gamma1 * log(mu)) for zinbl.mu, zigl.mu, zipl.mu, zilnl.mu
#'   \item Linear-linear: pi = logit^{-1}(gamma0 - gamma1/H * mu) for zinbll, zipll, zigll, zilnll
#' }
#'
#' @seealso \code{\link{modskurt_spec}}, \code{\link{modskurt_fit}}, \code{\link{modskurt_plot}}
#'
#' @examples
#' # Simulate count data with zero-inflated negative binomial
#' sim_count <- modskurt_sim(N = 150, dist = "zinb",
#'                           H = 20, m = 0.5, s = 0.15,
#'                           r = 0.5, d = 0, p = 1,
#'                           seed = 123)
#' plot(sim_count$x, sim_count$y, main = "ZINB simulated data")
#'
#' # Simulate density data with zero-inflated gamma
#' sim_dens <- modskurt_sim(N = 100, dist = "zig",
#'                          H = 0.8, m = 0.4, s = 0.1,
#'                          seed = 456)
#' plot(sim_dens$x, sim_dens$y, main = "ZIG simulated data")
#'
#' # Simulate proportion data with zero-inflated beta
#' sim_prop <- modskurt_sim(N = 100, dist = "zitab",
#'                          H = 0.6, m = 0.5, s = 0.2,
#'                          seed = 789)
#' plot(sim_prop$x, sim_prop$y, main = "ZITAB simulated data")
#'
#' # Access true parameters used in simulation
#' sim_count$params
#'
#' @export
modskurt_sim <- function(N = 200, x = NULL, dist = "zitab",
		H = NULL, m = NULL, s = NULL,
		r = NULL, d = NULL, p = NULL,
		k = NULL, delta = 0.01, pi = 0.2,
		gamma0 = NULL, gamma1 = NULL,
		sigma = NULL,
		seed = NULL) {

	dist_names <- c("zinb", "zinbl", "zinbl.mu", "nb", "poisson", "bern",
			"tab", "zitab", "zig", "zigl.mu", "zigl",
			"zip", "zipl", "zipl.mu", "zinbll", "zipll",
			"gaussian", "zigll",
			"ziln", "zilnl.mu", "zilnl", "zilnll")

	dist_code <- match(dist, dist_names)
	
	if (is.na(dist_code)) stop("Invalid distribution name")
	
	if (missing(seed) || is.null(seed)) {
		seed <- as.integer(Sys.time()) %% 1e6
	}
	set.seed(seed)
	
	if (is.null(x)) {
		x <- sort(runif(N, 0, 1))
	} else {
		x <- sort(x)
		N <- length(x)
	}
	
	range_x <- diff(range(x))
	min_x <- min(x)
	
	if (is.null(H)) H <- rbeta(1, 2, 3)
	if (is.null(m)) m <- rbeta(1, 1, 1) * range_x + min_x
	if (is.null(s)) s <- exp(rnorm(1, -2.0, 0.3)) * range_x
	if (is.null(r)) r <- rbeta(1, 1.2, 1.2)
	if (is.null(d)) d <- exp(rnorm(1, 0.5, 1.0))
	if (is.null(p)) p <- rbeta(1, 1.2, 1.2) * 1.95 + 0.05
	if (is.null(k)) k <- rexp(1, 0.5)
	if (is.null(sigma)) sigma <- abs(rnorm(1, 1, 0.25))

	base <- function(x, H, m, s, r, d, p) {
		t1 <- r * exp(((x - m) / (r * s) - d) / p)
		t2 <- (1 - r) * exp(-((x - m) / ((1 - r) * s) + d) / p)
		(t1 + t2 - exp(-d / p) + 1)
	}
	
	mu <- H / (base(x, H, m, s, r, d, p)^p)
	
	if (dist_code %in% c(6, 7, 8)) {
		mu <- pmin(pmax(mu, 1e-6), 1 - 1e-6)
	} else {
		mu <- pmax(mu, 1e-6)
	}
	
	if (dist_code %in% c(1,2,3,8,9,10,11,12,13,14,15,16,18,19,20,21,22)) {
		if (is.null(gamma0) || is.null(gamma1)) {
			#prop_zero <- sum(mu == 0) / length(mu)
			#initial_zero_prob <- qlogis(pmin(pmax(prop_zero, 1e-6), 1-1e-6))
			#gamma0 <- 2 * initial_zero_prob
			#gamma1 <- -initial_zero_prob / (mean(mu[mu > 0]) / 2)
			gamma0 <- rnorm(1, 0, 1)
			gamma1 <- rnorm(1, 0, 1)
		
		}
	}
	
	#pi_vec <- if (!is.null(gamma0)) plogis(gamma0 + gamma1 * mu) else rep(pi, N)
	pi_vec <- if (dist_code %in% c(1, 9, 12, 19)) {
				plogis(gamma0)
			} else if (dist_code %in% c(2, 11, 13, 21)) {
				plogis(gamma0 + gamma1 * mu)
			} else if (dist_code %in% c(3, 8, 10, 14, 20)) {
				plogis(gamma0 + gamma1 * log(mu))
			} else if (dist_code %in% c(15, 16, 18, 22)) {
				plogis(-gamma1 / H * mu + gamma0)
			} else {
				rep(0, N)
			}
	
	if (dist_code %in% c(1:6, 12:16)) {
		lambda <- mu
		y <- switch(as.character(dist_code),
				"1" = ifelse(runif(N) < pi_vec, 0, rnbinom(N, mu = lambda, size = k)),
				"2" = ifelse(runif(N) < pi_vec, 0, rnbinom(N, mu = lambda, size = k)),
				"3" = ifelse(runif(N) < pi_vec, 0, rnbinom(N, mu = lambda, size = k)),
				"4" = rnbinom(N, mu = lambda, size = k),
				"5" = rpois(N, lambda),
				"6" = rbinom(N, size = 1, prob = lambda),
				"12" = ifelse(runif(N) < pi_vec, 0, rpois(N, lambda)),
				"13" = ifelse(runif(N) < pi_vec, 0, rpois(N, lambda)),
				"14" = ifelse(runif(N) < pi_vec, 0, rpois(N, lambda)),
				"15" = ifelse(runif(N) < pi_vec, 0, rnbinom(N, mu = lambda, size = k)),
				"16" = ifelse(runif(N) < pi_vec, 0, rpois(N, lambda))
		)
		y_cont <- rep(0, N)
		y_int <- y
	} else {
		# Beta distribution params (for tab, zitab): E[Y] = alpha/(alpha+beta) = mu
		alpha <- mu * k
		beta <- (1 - mu) * k
		# Gamma distribution params (for zig*): E[Y] = alpha_g/beta_g = mu
		alpha_g <- mu * k
		beta_g <- k
		# Log-normal params: lmu = log(mu), sigma
		lmu <- log(mu)
		y <- switch(as.character(dist_code),
				"7" = rbeta(N, alpha, beta),
				"8" = ifelse(runif(N) < pi_vec, runif(N, 0, delta), rbeta(N, alpha, beta)),
				"9" = ifelse(runif(N) < pi_vec, 0, rgamma(N, shape = alpha_g, rate = beta_g)),
				"10" = ifelse(runif(N) < pi_vec, 0, rgamma(N, shape = alpha_g, rate = beta_g)),
				"11" = ifelse(runif(N) < pi_vec, 0, rgamma(N, shape = alpha_g, rate = beta_g)),
				"17" = rnorm(N, mean = log(H) - p * log(base(x, H, m, s, r, d, p)), sd = k),
				"18" = ifelse(runif(N) < pi_vec, 0, rgamma(N, shape = alpha_g, rate = beta_g)),
				"19" = ifelse(runif(N) < pi_vec, 0, rlnorm(N, meanlog = lmu, sdlog = sigma)),
				"20" = ifelse(runif(N) < pi_vec, 0, rlnorm(N, meanlog = lmu, sdlog = sigma)),
				"21" = ifelse(runif(N) < pi_vec, 0, rlnorm(N, meanlog = lmu, sdlog = sigma)),
				"22" = ifelse(runif(N) < pi_vec, 0, rlnorm(N, meanlog = lmu, sdlog = sigma))
		)
		y_int <- rep(0, N)
		y_cont <- y
	}
	
	params <- list(
			H = H,
			m = m,
			s = s,
			r = r,
			d = d,
			p = p,
			k = k,
			sigma = sigma,
			pi = pi,
			gamma0 = gamma0,
			gamma1 = gamma1
	)
	
	list(
			x = x,
			y = y,
			y_int = y_int,
			y_cont = y_cont,
			dist_code = dist_code,
			dist_name = dist,
			params = params
	)
}

