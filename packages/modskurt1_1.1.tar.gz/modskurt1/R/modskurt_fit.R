#' Fit a Modskurt Model Using Stan
#'
#' Wrapper function to fit modskurt models using cmdstanr. Handles
#' initialization, sampling, and attaches the specification to the result.
#'
#' @param mod A compiled cmdstanr model object. Use \code{cmdstanr::cmdstan_model()}
#'   with the Stan file from \code{system.file("stan", "modskurt1.stan", package = "modskurt1")}.
#' @param spec A list of data returned by \code{\link{modskurt_spec}}.
#' @param params Optional list of true parameter values for initialization
#'   (e.g., from \code{\link{modskurt_sim}}).
#' @param iter_sampling Number of post-warmup iterations per chain. Default is 2000.
#' @param iter_warmup Number of warmup iterations per chain. Default is 1000.
#' @param chains Number of MCMC chains. Default is 4.
#' @param parallel_chains Number of chains to run in parallel. Default is 4.
#' @param seed Random seed for reproducibility. If NULL, generates from system time.
#' @param ... Additional arguments passed to \code{mod$sample()}.
#'
#' @return A cmdstanr fit object with the specification attached as an attribute
#'   (\code{attr(fit, "spec")}).
#'
#' @details
#' The function uses \code{\link{modskurt_init}} to generate initial values
#' for each chain. The fit object can be used with standard cmdstanr methods
#' like \code{$summary()}, \code{$draws()}, and \code{$diagnostic_summary()}.
#'
#' For large datasets or complex models, consider increasing \code{iter_warmup}
#' and using \code{adapt_delta} via the \code{...} argument.
#'
#' @examples
#' \dontrun{
#' # Load the Stan model
#' stan_path <- system.file("stan", "modskurt1.stan", package = "modskurt1")
#' mod <- cmdstanr::cmdstan_model(stan_path)
#'
#' # Create specification
#' spec <- modskurt_spec(x, y, distribution = "zinb")
#'
#' # Fit the model
#' fit <- modskurt_fit(mod, spec, chains = 4)
#'
#' # Check results
#' fit$summary()
#' fit$diagnostic_summary()
#' }
#'
#' @seealso \code{\link{modskurt_spec}}, \code{\link{modskurt_init}},
#'   \code{\link{modskurt_plot}}, \code{\link{modskurt_LL_AIC}}
#'
#' @export
modskurt_fit <- function(mod, spec,
		params = NULL,
		iter_sampling = 2000,
		iter_warmup = 1000,
		chains = 4,
		parallel_chains = 4,
		seed = NULL,
		...) {

	if (is.null(seed)) {
		seed <- as.integer(Sys.time()) %% 1e6
	}

	init_fun <- function() modskurt_init(spec, params = params)

	fit <- mod$sample(
			data = spec,
			init = init_fun,
			iter_sampling = iter_sampling,
			iter_warmup = iter_warmup,
			chains = chains,
			parallel_chains = parallel_chains,
			seed = seed,
			...
	)

	attr(fit, "spec") <- spec
	return(fit)
}
