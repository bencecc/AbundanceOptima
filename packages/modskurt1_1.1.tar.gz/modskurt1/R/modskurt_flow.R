###############################################################################
#' Model Selection Workflow for Modskurt Models
#'
#' Performs automated model selection across multiple mean curve shapes and error
#' distributions. The function implements a two-level selection procedure:
#' (1) selects the best error distribution within each mean curve configuration,
#' (2) selects the overall best model across all mean curves based on AIC.
#'
#' @param df Data frame containing response and predictor variables. Must include
#'   columns for the response, predictor, and metadata (ECOREGION, SPECIES, YEAR,
#'   SAMPLED_AREA, LAT, LON).
#' @param resp.var Character string specifying the response variable column name.
#'   One of: "abund" (count), "density", "prob.occ" (proportion), "pres.abs" (binary).
#' @param pred.var Character string specifying the predictor variable column name
#'   (e.g., "LAT" for latitude).
#' @param mod A compiled cmdstanr model object from \code{cmdstanr::cmdstan_model()}.
#' @param latlon.range Data frame with geographic range limits. Must contain columns
#'   \code{min.lat} and \code{max.lat} for validating mode estimates.
#' @param max.resp Data frame with maximum expected response value. Must contain
#'   column \code{max.resp} for validating height estimates.
#' @param plot.res Logical. If TRUE, display fitted trend plots during model fitting.
#' @param custom.dist Optional character vector of distribution names to use instead of
#'   the default distributions for the response type. If NULL (default), uses the
#'   standard distributions based on resp.var. Must be valid distribution names from
#'   the supported set (see Details).
#' @param ... Additional arguments (currently unused).
#'
#' @return A list with two elements:
#'   \item{model}{Data frame with model results including:
#'     \itemize{
#'       \item ECOREGION, SPECIES, YEAR: Metadata from input
#'       \item H.{pred.var}, m.{pred.var}: Estimated height and mode
#'       \item SAMPLED_AREA: Mean sampled area
#'       \item geog.range, resp.range: Logical flags for estimate validity
#'       \item LAT/LON statistics: Mean, min, max coordinates
#'       \item SELECTED_MODEL_{pred.var}: Best model name (curve_distribution)
#'       \item AIC, AICc, n_params, log_lik: Model fit statistics
#'       \item diverg, tree, ebfmi, nchains: MCMC diagnostics
#'     }
#'   }
#'   \item{plot.model}{List with point.df and trend.df for plotting}
#'
#' @details
#' The function fits models using 6 mean curve configurations:
#' \describe{
#'   \item{Mr0.5d0p1}{Symmetric (r=0.5), no displacement (d=0), standard kurtosis (p=1)}
#'   \item{Mr0.5p1}{Symmetric, estimate d, standard kurtosis}
#'   \item{Md0p1}{Estimate r, no displacement, standard kurtosis}
#'   \item{Mp1}{Estimate r and d, standard kurtosis}
#'   \item{Md0}{Estimate r and p, no displacement}
#'   \item{M}{Full model: estimate r, d, and p}
#' }
#'
#' Error distributions depend on response type:
#' \itemize{
#'   \item Count (abund): zinbl, zinbl.mu, zinbll, zinb, zipl, zipl.mu, zipll, nb, zip, poisson, gaussian
#'   \item Density: zig, zigl, zigl.mu, zigll, ziln, zilnl, zilnl.mu, zilnll
#'   \item Proportion (prob.occ): zitab, tab
#'   \item Binary (pres.abs): bern
#' }
#'
#' Model selection uses AIC. The function handles sign changes for negative
#' predictor values (e.g., negative latitudes in Southern Hemisphere).
#'
#' @seealso \code{\link{modskurt_fit}}, \code{\link{modskurt_spec}},
#'   \code{\link{modskurt_LL_AIC}}, \code{\link{modskurt_plot}}
#'
#' @examples
#' \dontrun{
#' # Load compiled Stan model
#' mod <- cmdstanr::cmdstan_model(modskurt_stan_path())
#'
#' # Prepare data frame with required columns
#' df <- data.frame(
#'   LAT = runif(100, 30, 50),
#'   abund = rpois(100, lambda = 10),
#'   ECOREGION = "Mediterranean",
#'   SPECIES = "Chromis chromis",
#'   YEAR = 2020,
#'   SAMPLED_AREA = 100,
#'   LON = runif(100, 5, 15)
#' )
#'
#' # Define validation ranges
#' latlon.range <- data.frame(min.lat = 30, max.lat = 50)
#' max.resp <- data.frame(max.resp = 100)
#'
#' # Run model selection
#' result <- modskurt_flow(
#'   df = df,
#'   resp.var = "abund",
#'   pred.var = "LAT",
#'   mod = mod,
#'   latlon.range = latlon.range,
#'   max.resp = max.resp,
#'   plot.res = FALSE
#' )
#'
#' # View results
#' result$model
#'
#' # Run with custom distributions (subset of defaults)
#' result_custom <- modskurt_flow(
#'   df = df,
#'   resp.var = "abund",
#'   pred.var = "LAT",
#'   mod = mod,
#'   latlon.range = latlon.range,
#'   max.resp = max.resp,
#'   plot.res = FALSE,
#'   custom.dist = c("zinb", "nb", "poisson")
#' )
#' }
#'
#' @export
#' @importFrom dplyr filter reframe rename
#' @importFrom foreach foreach %do%
#' @importFrom rlang sym
modskurt_flow <- function(df, resp.var, pred.var, mod, latlon.range, max.resp, plot.res, custom.dist = NULL, ...) {

	resp.type <- switch(resp.var,
			abund="count",
			density="density",
			prob.occ="proportion",
			pres.abs="binary"
	)

	mean.curve <- c("Mr0.5d0p1", "Mr0.5p1", "Md0p1", "Mp1", "Md0", "M")

	shape.pars <-  function(mean.curve) {
		switch(mean.curve,
				Mr0.5d0p1=c(0,0,0), # parms=0 use default value, not estimate
				Mr0.5p1=c(0,1,0),
				Md0p1=c(1,0,0),
				Mp1=c(1,1,0),
				Md0=c(1,0,1),
				M=c(1,1,1))
	}

	# Use custom distributions if provided, otherwise use defaults based on resp.var
	if (!is.null(custom.dist)) {
		error.dist <- custom.dist
	} else {
		error.dist <- switch(resp.var,
				abund=c("zinbl", "zinbl.mu", "zinbll", "zinb", "zipl", "zipl.mu", "zipll", "nb", "zip", "poisson", "gaussian"),
				density=c("zig", "zigl", "zigl.mu", "zigll", "ziln", "zilnl", "zilnl.mu", "zilnll"),
				prob.occ=c("zitab", "tab"),
				pres.abs=c("bern")
		)
	}

	if(all(df[[pred.var]]<0)) {

		change.sign <- TRUE
		df[[pred.var]] <- -df[[pred.var]]

	} else {change.sign=FALSE}


	# Fit each mean curve function using each of the allowed error distributions
	mod.res <- foreach::foreach(i = 1:length(mean.curve)) %do% {

		sh.pars <- shape.pars(mean.curve[i])

		mod.tmp <- foreach::foreach(j = 1:length(error.dist)) %do% {

			spec <- modskurt_spec(x=df[[pred.var]], y=df[[resp.var]],
					response_type = resp.type,
					distribution=error.dist[j],
					use_r=sh.pars[1], use_d=sh.pars[2], use_p=sh.pars[3])

			tryCatch({mfit <- modskurt_fit(spec, mod = mod, chains=4)}, error=function(e) NULL)

			if(!is.null(mfit)) {

				# Check that H and m estimates are within observed ranges
				m.est <- mfit$summary(variable="m")$mean
				resp.est <- mfit$summary(variable="H")$mean
				geog.range <- NULL
				resp.range <- NULL

				if(change.sign==TRUE) {m.est=-m.est}

				if(pred.var=="LAT"&m.est>=latlon.range$min.lat&m.est<=latlon.range$max.lat) {geog.range <- TRUE
				} else {geog.range <- FALSE}

				if(resp.est<=max.resp$max.resp) {resp.range <- TRUE
				} else {resp.range <- FALSE}

				# AIC
				aic <- modskurt_LL_AIC(mfit, spec)

				# add plot
				p.trend <- modskurt_plot(fit=mfit, spec,
						type="mean", interval="none",
						quantiles=NULL,
						apply_zi = TRUE,
						show_draws = FALSE,
						combine = FALSE,
						xlab=pred.var,
						plot = plot.res)

				out <- list(model=mfit, aic=aic, curve_distr=paste(mean.curve[i], "_", error.dist[j], sep=""),
						geog.range=geog.range, resp.range=resp.range, plot.df=p.trend)

			} else {out <- NULL}

		}

		if(!is.null(mod.tmp)) {

			# select error distribution with lowest AIC for the given 'i' mean.curve
			aic.distr.sel <- which.min(unlist(lapply(mod.tmp, function(x) x[[2]][[2]])))
			mod.tmp[[aic.distr.sel]]

		}

	}

	aic.model.sel <- which.min(unlist(lapply(mod.res, function(x) x[[2]][[2]])))
	selected.model <- mod.res[[aic.model.sel]]
	final.model <- selected.model$model

# collect warns for m.orig
	diagn <- final.model$diagnostic_summary()
	warns <- list()

	if(sum(diagn$num_divergent)>0) {
		warns[[1]] <- sum(diagn$num_divergent)
	} else {warns[[1]] <- 0}

	if(sum(diagn$num_max_treedepth)>0) {
		warns[[2]] <- sum(diagn$num_max_treedepth)
	} else {warns[[2]] <- 0}

	if(length(which(diagn$ebfmi<0.3)<0)) {
		warns[[3]] <- length(which(diagn$ebfmi)<0.3)
	} else {warns[[3]] <- 0}

	warns[[4]] <- final.model$num_chains()

# combine output
	out <- final.model$summary(variables = c(
					"H", "m", "s", "r", "d", "p", "k", "sigma", "gamma0", "gamma1"
			))

	if(change.sign==TRUE) {
		out[which(out$variable%in%"m"),c("mean")] <-
				-out[which(out$variable%in%"m"), c("mean")]
		df[[pred.var]] <- -df[[pred.var]]
	}

	comb.res <- data.frame(
					ECOREGION=unique(df$ECOREGION),
					SPECIES=unique(df$SPECIES),
					YEAR=unique(df$YEAR),
					H = as.vector(unlist(out[1,2])),
					m = as.vector(unlist(out[2,2])),
					SAMPLED_AREA=mean(df$SAMPLED_AREA),
					geog.range=selected.model$geog.range,
					resp.range=selected.model$resp.range,
					LAT.MEAN=mean(df$LAT, na.rm=T),
					LON.MEAN=mean(df$LON, na.rm=T),
					LAT.MIN=min(df$LAT),
					LAT.MAX=max(df$LAT),
					LON.MIN=min(df$LON),
					LON.MAX=max(df$LON),
					SELECTED_MODEL=selected.model$curve_distr,
					AIC = selected.model$aic$AIC,
					AICc = selected.model$aic$AICc,
					n_params = selected.model$aic$n_params,
					log_lik = selected.model$aic$log_lik,
					diverg = warns[[1]],
					tree = warns[[2]],
					ebfmi = warns[[3]],
					nchains = warns[[4]]
			) |>
			dplyr::rename(!!rlang::sym(paste("H", pred.var, sep=".")):="H",
					!!rlang::sym(paste("m", pred.var, sep=".")):="m",
					!!rlang::sym(paste("SELECTED_MODEL_", pred.var, sep="")):="SELECTED_MODEL"
			)

	# return
	list(model=comb.res, plot.model=selected.model$plot.df)

}
