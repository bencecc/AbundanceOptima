###############################################################################
#' Plot Modskurt Model Results
#'
#' Comprehensive plotting function for modskurt models. Generates posterior
#' predictive plots, prior predictive draws, diagnostic panels, or returns
#' data for custom plotting.
#'
#' @param fit A fitted cmdstanr model object from \code{\link{modskurt_fit}}.
#'   If NULL, generates prior predictive draws.
#' @param spec A specification list from \code{\link{modskurt_spec}}. Required.
#' @param type Character string specifying plot type:
#'   \itemize{
#'     \item "mean": Plot posterior mean trend (default)
#'     \item "median": Plot posterior median trend
#'     \item "quantile": Plot specified quantiles
#'     \item "diagnostics": Generate diagnostic panel (density overlay, mean check,
#'           interval check, parameter densities)
#'   }
#' @param interval Type of uncertainty interval:
#'   \itemize{
#'     \item "ci": 95\% credible interval (default)
#'     \item "se": Mean +/- 1.96 * SD
#'     \item "none": No interval
#'   }
#' @param draws Number of posterior draws to use. Default is 200.
#' @param show_draws Logical. If TRUE, overlay individual posterior draws. Default is FALSE.
#' @param n_show_draws Number of draws to overlay when show_draws is TRUE. Default is 50.
#' @param apply_zi Logical. If TRUE, apply zero-inflation adjustment to predictions.
#'   Default is TRUE.
#' @param quantiles Numeric vector of quantiles to plot (e.g., c(0.1, 0.9)).
#'   Only used when type = "quantile".
#' @param combine Logical. If TRUE and type = "diagnostics", combine all diagnostic
#'   plots into a single panel. Default is FALSE.
#' @param xlab Character string for x-axis label. Also used for column naming
#'   when plot = FALSE.
#' @param plot Logical. If TRUE, display the plot. If FALSE, return data frames
#'   for custom plotting. Default is FALSE.
#'
#' @return Depends on arguments:
#'   \itemize{
#'     \item If plot = TRUE: Displays plot and returns invisibly
#'     \item If plot = FALSE and type != "diagnostics": List with point.df and trend.df
#'     \item If type = "diagnostics" and combine = FALSE: List of 4 ggplot objects
#'     \item If type = "diagnostics" and combine = TRUE: Combined panel plot
#'     \item If fit = NULL: ggplot of prior predictive draws
#'   }
#'
#' @details
#' The function handles different distribution types automatically, applying
#' appropriate zero-inflation adjustments based on the distribution code.
#'
#' For diagnostics, four panels are generated:
#' \enumerate{
#'   \item Density overlay: Posterior predictive vs observed density
#'   \item Mean check: Distribution of predicted means vs observed mean
#'   \item Interval check: 95\% prediction intervals with observed data
#'   \item Parameter densities: Posterior distributions of all parameters
#' }
#'
#' @seealso \code{\link{modskurt_fit}}, \code{\link{modskurt_spec}}, \code{\link{modskurt_LL_AIC}}
#'
#' @examples
#' \dontrun{
#' # Simulate and fit a model
#' sim <- modskurt_sim(N = 100, dist = "zinb", H = 15, m = 0.5, s = 0.1, seed = 42)
#' spec <- modskurt_spec(sim$x, sim$y, distribution = "zinb")
#' mod <- cmdstanr::cmdstan_model(modskurt_stan_path())
#' fit <- modskurt_fit(spec, mod = mod, chains = 2)
#'
#' # Plot posterior mean with 95% CI
#' modskurt_plot(fit, spec, type = "mean", interval = "ci", plot = TRUE)
#'
#' # Plot with individual posterior draws overlaid
#' modskurt_plot(fit, spec, type = "mean", show_draws = TRUE, n_show_draws = 30, plot = TRUE)
#'
#' # Generate diagnostic plots
#' diag_plots <- modskurt_plot(fit, spec, type = "diagnostics")
#' diag_plots$density_overlay
#' diag_plots$parameter_densities
#'
#' # Get data for custom plotting
#' plot_data <- modskurt_plot(fit, spec, type = "mean", plot = FALSE, xlab = "Temperature")
#' head(plot_data$trend.df)
#'
#' # Prior predictive plot (no fit provided)
#' modskurt_plot(fit = NULL, spec, draws = 100)
#' }
#'
#' @export
modskurt_plot <- function(fit = NULL, spec,
		type = c("mean", "median", "quantile", "diagnostics"),
		interval = c("ci", "se", "none"),
		draws = 200,
		show_draws = FALSE,
		n_show_draws = 50,
		apply_zi = TRUE,
		quantiles = NULL,
		combine = FALSE,
		xlab="",
		plot = FALSE) {

	type <- match.arg(type)
	interval <- match.arg(interval)

	if (is.null(fit) && is.null(spec)) stop("Either 'fit' or 'spec' must be provided.")

	dist_code <- spec$dist_code
	x <- spec$x
	y <- if (dist_code %in% c(1:6, 12:16)) spec$y_int else spec$y_cont

	base <- function(x, H, m, s, r, d, p) {
		t1 <- r * exp(((x - m) / (r * s) - d) / p)
		t2 <- (1 - r) * exp(-((x - m) / ((1 - r) * s) + d) / p)
		t1 + t2 - exp(-d / p) + 1
	}
	
	if (is.null(fit)) {
		# Prior predictive draws
		n_draws <- draws
		range_x <- max(x) - min(x)
		range_y <- max(y, na.rm = TRUE)
		
		gamma0_prior <- rnorm(1, 0, 1)
		gamma1_prior <- rnorm(1, 0, 1)
#		prop_zero <- sum(y == 0) / length(y)
#		initial_zero_prob <- qlogis(pmin(pmax(prop_zero, 1e-6), 1-1e-6))
#		gamma0_prior <- 2 * initial_zero_prob
#		gamma1_prior <- -initial_zero_prob / (mean(y[y > 0]) / 2)
		
		prior_samples <- replicate(n_draws, {
					H <- rbeta(1, 2, 3) * range_y
					m <- rbeta(1, 1, 1) * range_x + min(x)
					s <- exp(rnorm(1, -2.0, 0.6)) * range_x
					r <- rbeta(1, 1.2, 1.2)
					d <- exp(rnorm(1, 0.5, 1.0))
					p <- rbeta(1, 1.2, 1.2) * 1.95 + 0.05
					mu_raw <- H / (base(x, H, m, s, r, d, p)^p)
					lmu <- log(mu_raw)					
					if (apply_zi && dist_code %in% c(1, 9, 12, 19)) {
						pi_x <- plogis(gamma0_prior)
						mu_adj <- (1 - pi_x) * mu_raw
					} else if (apply_zi && dist_code %in% c(2, 11, 13, 21)) {
						pi_x <- plogis(gamma0_prior + gamma1_prior * mu_raw)
						mu_adj <- (1 - pi_x) * mu_raw
					} else if (apply_zi && dist_code %in% c(3, 8, 10, 14, 20)) {
						pi_x <- plogis(gamma0_prior + gamma1_prior * lmu)
						mu_adj <- (1 - pi_x) * mu_raw
					} else if(apply_zi && dist_code %in% c(15, 16, 18, 22)) {
						pi_x <- plogis(-gamma1_prior / H * mu_raw + gamma0_prior)
						mu_adj <- (1 - pi_x) * mu_raw
					} else if (dist_code == 6) {
						mu_adj <- plogis(lmu)
					} else {
						mu_adj <- mu_raw
					}									
					data.frame(x = x, mu = mu_adj)
				}, simplify = FALSE)
		
		pred_df <- do.call(rbind, prior_samples)
		pred_df$draw <- rep(1:n_draws, each = length(x))
		
		p <- ggplot2::ggplot(pred_df, ggplot2::aes(x = x, y = mu, group = draw)) +
				ggplot2::geom_line(alpha = 0.1, color = "blue") +
				ggplot2::geom_point(data = data.frame(x = x, y = y),
						mapping = ggplot2::aes(x = x, y = y),
						size = 1.5, alpha = 0.8, inherit.aes = FALSE) +
				ggplot2::labs(title = "Prior Predictive Draws", x = xlab, y = "mu") +
				ggplot2::theme_bw(base_size = 12) +
				ggplot2::theme(legend.position = "none")
		return(p)
		
	} else {
		
		# Extract parameters - gamma1 only for distributions that use it
		params_to_extract <- c("H", "m", "s", "r", "d", "p", "gamma0")
		if (dist_code %in% c(2, 3, 8, 10, 11, 13, 14, 15, 16, 18, 20, 21, 22)) {
			params_to_extract <- c(params_to_extract, "gamma1")
		}
		if (dist_code %in% c(17, 19:22)) {
			params_to_extract <- c(params_to_extract, "sigma")
		}
		draws_df <- posterior::as_draws_df(fit$draws(params_to_extract))
		# Add gamma1 = 0 for distributions that don't use it (for consistent downstream code)
		if (!"gamma1" %in% names(draws_df)) {
			draws_df$gamma1 <- 0
		}
		n_draws <- min(nrow(draws_df), draws)
		
		if (type == "diagnostics") {
			# Diagnostics
			yrep <- posterior::as_draws_matrix(fit$draws("y_rep"))
			yrep_sub <- yrep[1:min(draws, nrow(yrep)), ]
			
			if (ncol(yrep_sub) != length(y)) {
				stop("Mismatch between y and y_rep dimensions.")
			}
			
			p1 <- bayesplot::ppc_dens_overlay(y, yrep_sub) +
					ggplot2::labs(title = "Density Overlay") +
					ggplot2::theme_minimal()
			
			p2 <- ggplot2::ggplot(data.frame(means = rowMeans(yrep_sub)), ggplot2::aes(x = means)) +
					ggplot2::geom_histogram(bins = 40, fill = "steelblue", alpha = 0.6) +
					ggplot2::geom_vline(xintercept = mean(y), color = "red", linewidth = 1, linetype = "dashed") +
					ggplot2::labs(title = "Mean Check", x = "", y = "Density") +
					ggplot2::theme_minimal()
			
			interval_check <- data.frame(
					x = x,
					observed = y,
					predicted_mean = colMeans(yrep_sub),
					lower = apply(yrep_sub, 2, quantile, probs = 0.025),
					upper = apply(yrep_sub, 2, quantile, probs = 0.975)
			)
			
			p3 <- ggplot2::ggplot(interval_check, ggplot2::aes(x = x)) +
					ggplot2::geom_point(ggplot2::aes(y = observed), color = "black") +
					ggplot2::geom_line(ggplot2::aes(y = predicted_mean), color = "blue") +
					ggplot2::geom_ribbon(ggplot2::aes(ymin = lower, ymax = upper), alpha = 0.2) +
					ggplot2::labs(title = "Interval Check", x = xlab, y = "Value") +
					ggplot2::theme_minimal()
			
			# Only include gamma0, gamma1, sigma based on distribution
			param_names <- names(draws_df)[which(names(draws_df) %in%
									if (dist_code %in% c(2,3,8:16,18,20:22))
										c("H", "m", "s", "r", "d", "p", "gamma0", "gamma1", if (dist_code %in% c(17,19:22)) "sigma")
									else if (dist_code %in% c(17, 19))
										c("H", "m", "s", "r", "d", "p", "gamma0", "sigma")
									else
										c("H", "m", "s", "r", "d", "p"))]
			
			param_densities_df <- NULL
			for (param in param_names) {
				param_densities_df <- rbind(param_densities_df,
						data.frame(par = param, value = as.vector(draws_df[[param]])))
			}
			
			p4 <- ggplot2::ggplot(param_densities_df |> dplyr::mutate(par = factor(par, levels = param_names)), ggplot2::aes(x = value)) +
					ggplot2::geom_density(fill = "skyblue", alpha = 0.5) +
					ggplot2::labs(title = "Posterior Densities", x = "", y = "Density") +
					ggplot2::facet_wrap(. ~ par, scales = "free", ncol = 2) +
					ggplot2::theme_minimal()
			
			if (combine) {
				all_plots <- c(list(p4, p1, p2, p3))
				combined_plot <- gridExtra::marrangeGrob(grobs = all_plots, nrow = 2, ncol = 2)
				return(combined_plot[[1]])
			} else {
				return(list(
								density_overlay = p1,
								mean_check = p2,
								interval_check = p3,
								parameter_densities = p4
						))
			}
		} else {
			
			# Quantile filtering on gamma1
			if ("gamma1" %in% names(draws_df)) {
				gamma1_q <- quantile(draws_df$gamma1, probs = c(0.025, 0.975), na.rm = TRUE)
				draws_df <- draws_df |> dplyr::filter(gamma1 >= gamma1_q[1], gamma1 <= gamma1_q[2])
			}
			
			draws_df <- draws_df |>  dplyr::mutate(draw=dplyr::row_number())
			
			pred_grid <- expand.grid(x = x, draw = 1:nrow(draws_df))
			pred_grid <- pred_grid |> dplyr::left_join(draws_df, by = "draw")
			
			base_val <- base(pred_grid$x, pred_grid$H, pred_grid$m, pred_grid$s, pred_grid$r, pred_grid$d, pred_grid$p)
			pred_grid$lmu <- log(pred_grid$H) - pred_grid$p * log(base_val)
			pred_grid$mu <- exp(pred_grid$lmu)
			
			# ZERO INFLATION
			# simple zero-infation (gamma0): dist_code %in% c(1,9,12,19)
			# linked to mu (gamma0 + gamma1 * mu): dist_code %in% c(2,11,13,21)
			# linked to lmu (gamma0 + gamma1 * lmu): dist_code %in% c(3,10,14,20)
			# modskurt scaled (-gamma1/H * mu + gamma0): dist_code %in% c(15,16,18,22)
			if (apply_zi && dist_code %in% c(1, 9, 12, 19)) {
				pred_grid$pi <- plogis(pred_grid$gamma0)
				pred_grid$mu_adj <- (1 - pred_grid$pi) * pred_grid$mu
			} else if (apply_zi && dist_code %in% c(2, 11, 13, 21)) {
				pred_grid$pi <- plogis(pred_grid$gamma0 + pred_grid$gamma1 * pred_grid$mu)
				pred_grid$mu_adj <- (1 - pred_grid$pi) * pred_grid$mu
			} else if (apply_zi && dist_code %in% c(3, 8, 10, 14, 20)) {
				pred_grid$pi <- plogis(pred_grid$gamma0 + pred_grid$gamma1 * pred_grid$lmu)
				pred_grid$mu_adj <- (1 - pred_grid$pi) * pred_grid$mu
			} else if(apply_zi && dist_code %in% c(15, 16, 18, 22)) {
				pred_grid$pi <- plogis(-pred_grid$gamma1 / pred_grid$H * pred_grid$mu + pred_grid$gamma0)
				pred_grid$mu_adj <- (1 - pred_grid$pi) * pred_grid$mu
			} else if (dist_code == 6) {
				pred_grid$mu_adj <- plogis(pred_grid$lmu)
			} else {
				pred_grid$mu_adj <- pred_grid$mu
			}			
			
			summary_df <- pred_grid |>
					dplyr::group_by(x) |>
					dplyr::reframe(
							mu_mean = mean(mu_adj),
							mu_median = median(mu_adj),
							mu_sd = sd(mu_adj),
							all_vals = list(mu_adj)
					)
			
			if(plot==TRUE) {
				
				if (interval == "ci") {
					ymin <- sapply(summary_df$all_vals, quantile, probs = 0.025)
					ymax <- sapply(summary_df$all_vals, quantile, probs = 0.975)
				} else if (interval == "se") {
					ymin <- summary_df$mu_mean - 1.96 * summary_df$mu_sd
					ymax <- summary_df$mu_mean + 1.96 * summary_df$mu_sd
				} else {
					ymin <- ymax <- NA
				}
				
				p <- ggplot2::ggplot(summary_df, ggplot2::aes(x = x)) 
								
				if (dist_code == 6) {
					p <- p + ggplot2::geom_point(data = data.frame(x = x, y = jitter(y, amount = 0.05)),
							ggplot2::aes(x = x, y = y), shape = 21, size = 2, alpha = 0.6, fill = "black")
				} else {
					p <- p + ggplot2::geom_point(data = data.frame(x = x, y = y), ggplot2::aes(x = x, y = y), size = 1.5, alpha = 0.8)
				}
				
				if (!is.na(ymin[1])) {
					p <- p + ggplot2::geom_ribbon(ggplot2::aes(ymin = ymin, ymax = ymax), fill = "skyblue", alpha = 0.2)
				}
				
				if (type == "mean") {
					p <- p + ggplot2::geom_line(ggplot2::aes(y = mu_mean), color = "red", linewidth = 1.2)
				} else if (type == "median") {
					p <- p + ggplot2::geom_line(ggplot2::aes(y = mu_median), color = "blue", linewidth = 1.2)
				}
				
				if (!is.null(quantiles)) {
					quantile_df <- do.call(rbind, lapply(quantiles, function(q) {
										q_vals <- sapply(summary_df$all_vals, quantile, probs = q)
										data.frame(x = summary_df$x, value = q_vals, quantile = as.factor(q))
									}))
					p <- p + ggplot2::geom_line(data = quantile_df,
							ggplot2::aes(x = x, y = value, group = quantile, linetype = quantile),
							linewidth = 0.4)
				}
				
				if (show_draws) {
					draw_ids <- sample(unique(pred_grid$draw), size = min(n_show_draws, n_draws))
					draw_lines <- pred_grid[pred_grid$draw %in% draw_ids, ]
					p <- p + ggplot2::geom_line(data = draw_lines, ggplot2::aes(x = x, y = mu_adj, group = draw),
							color = "blue", linewidth = 0.2, alpha = 0.1)
				}
				
				p <- p + ggplot2::labs(title = "", x = xlab, y = "Observed & Fitted") +
						ggplot2::theme_bw(base_size = 12) +
						ggplot2::theme(legend.position = "none",
						axis.text.x=ggplot2::element_text(size=12),
						axis.text.y=ggplot2::element_text(size=12),
						axis.title.x=ggplot2::element_text(size=14),
						panel.grid.major=ggplot2::element_line(colour=NA), panel.grid.minor=ggplot2::element_line(colour=NA),
						panel.background = ggplot2::element_blank(), panel.border=ggplot2::element_rect(colour="black"))

				plot(p)
				
			} else {
				
				point.df <- data.frame(x=x, y=y)
				trend.df <- summary_df |> dplyr::select(c("x", "mu_mean"))
				if (nchar(xlab) > 0) {
					point.df <- point.df |> dplyr::rename(!!rlang::sym(xlab):=x)
					trend.df <- trend.df |> dplyr::rename(!!rlang::sym(xlab):=x)
				}
						
				return(list(point.df=point.df, trend.df=trend.df))
			
			}
			
		}
		
	}
}


