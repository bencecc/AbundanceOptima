###############################################################################
#' Specify Model Input for Modskurt Stan Model
#'
#' Creates a data specification list for fitting modskurt models with Stan.
#' This function prepares all necessary data inputs including response type
#' detection, hyperparameters, and shape parameter constraints.
#'
#' @param x Numeric vector of covariate (predictor) values.
#' @param y Numeric vector of response values.
#' @param response_type Character string specifying the response type. One of
#'   "count", "binary", "proportion", or "density". If NULL (default), inferred
#'   from the distribution.
#' @param distribution Character string specifying the error distribution. One of:
#'   \itemize{
#'     \item Count: "zinb", "zinbl", "zinbl.mu", "nb", "poisson", "zip", "zipl",
#'           "zipl.mu", "zinbll", "zipll", "gaussian"
#'     \item Proportion: "tab", "zitab"
#'     \item Density: "zig", "zigl.mu", "zigl", "zigll",
#'           "ziln", "zilnl.mu", "zilnl", "zilnll"
#'     \item Binary: "bern"
#'   }
#' @param use_r Integer (0 or 1). If 1, estimate asymmetry parameter r; if 0, fix at fix_r.
#' @param fix_r Numeric value for r when use_r = 0. Default is 0.5 (symmetric).
#' @param use_d Integer (0 or 1). If 1, estimate displacement parameter d; if 0, fix at fix_d.
#' @param fix_d Numeric value for d when use_d = 0. Default is 0.
#' @param use_p Integer (0 or 1). If 1, estimate kurtosis parameter p; if 0, fix at fix_p.
#' @param fix_p Numeric value for p when use_p = 0. Default is 1.
#' @param delta Smoothing parameter for zero-inflated beta distribution. Default is 0.01.
#' @param params Optional list of parameters (e.g., from \code{\link{modskurt_sim}}).
#'   Currently not used but reserved for future functionality.
#'
#' @return A named list containing all Stan data inputs:
#'   \item{N}{Number of observations}
#'   \item{x}{Predictor values}
#'   \item{y_int}{Integer response (for count/binary)}
#'   \item{y_cont}{Continuous response (for proportion/density)}
#'   \item{dist_code}{Integer code for distribution (1-22)}
#'   \item{max_y}{Maximum positive y value (for scaling)}
#'   \item{range_x, min_x}{Range and minimum of x (for parameter scaling)}
#'   \item{hp_*}{Hyperparameters for priors}
#'   \item{use_r, fix_r, use_d, fix_d, use_p, fix_p}{Shape parameter constraints}
#'   \item{delta}{Smoothing parameter}
#'
#' @details
#' The function automatically detects response type from the distribution name
#' and formats data appropriately (integer for counts, continuous for densities).
#'
#' Shape parameters can be fixed to simplify the model:
#' \itemize{
#'   \item \code{r = 0.5}: Symmetric curve
#'   \item \code{d = 0}: No vertical displacement
#'   \item \code{p = 1}: Standard kurtosis (Gaussian-like tails)
#' }
#'
#' Common model configurations:
#' \itemize{
#'   \item Full model: use_r=1, use_d=1, use_p=1
#'   \item Symmetric: use_r=0, fix_r=0.5, use_d=1, use_p=1
#'   \item Simple unimodal: use_r=0, fix_r=0.5, use_d=0, fix_d=0, use_p=0, fix_p=1
#' }
#'
#' @seealso \code{\link{modskurt_sim}}, \code{\link{modskurt_fit}}, \code{\link{modskurt_init}}
#'
#' @examples
#' # Simulate data
#' sim <- modskurt_sim(N = 100, dist = "zinb", H = 15, m = 0.5, s = 0.1, seed = 42)
#'
#' # Create specification with full model (estimate all shape parameters)
#' spec_full <- modskurt_spec(sim$x, sim$y, distribution = "zinb")
#'
#' # Create specification with symmetric constraint (fix r = 0.5)
#' spec_sym <- modskurt_spec(sim$x, sim$y, distribution = "zinb",
#'                           use_r = 0, fix_r = 0.5)
#'
#' # Create specification with simple unimodal (fix r, d, p)
#' spec_simple <- modskurt_spec(sim$x, sim$y, distribution = "zinb",
#'                              use_r = 0, fix_r = 0.5,
#'                              use_d = 0, fix_d = 0,
#'                              use_p = 0, fix_p = 1)
#'
#' # Check the specification
#' names(spec_full)
#' spec_full$dist_code
#' spec_full$N
#'
#' @export
modskurt_spec <- function(x, y,
		response_type = NULL,
		distribution = c("zinb", "zinbl", "zinbl.mu", "nb", "poisson", "bern",
				"tab", "zitab", "zig", "zigl.mu", "zigl",
				"zip", "zipl", "zipl.mu", "zinbll", "zipll",
				"gaussian", "zigll",
				"ziln", "zilnl.mu", "zilnl", "zilnll"),
		use_r = 1,
		fix_r = 0.5,
		use_d = 1,
		fix_d = 0,
		use_p = 1,
		fix_p = 1,
		delta = 0.01,
		params=NULL) {

	distribution <- match.arg(distribution)
	
	dist_names <- c("zinb", "zinbl", "zinbl.mu", "nb", "poisson", "bern",
			"tab", "zitab", "zig", "zigl.mu", "zigl",
			"zip", "zipl", "zipl.mu", "zinbll", "zipll",
			"gaussian", "zigll",
			"ziln", "zilnl.mu", "zilnl", "zilnll")
	dist_code <- match(distribution, dist_names)
	
	if (is.na(dist_code)) stop("Invalid distribution name")
	
	# Infer response type from distribution
	if (is.null(response_type)) {
		response_type <- switch(distribution,
				zinb = "count", zinbl = "count", zinbl.mu = "count",
				nb = "count", poisson = "count", bern = "binary",
				tab = "proportion", zitab = "proportion",
				zig = "density", zigl.mu = "density", zigl = "density",
				zip = "count", zipl = "count", zipl.mu = "count",
				zinbll = "count", zipll = "count",
				gaussian = "density", zigll = "density",
				ziln = "density", zilnl.mu = "density", zilnl = "density", zilnll = "density"
		)
	}
	
	is_discrete <- response_type %in% c("count", "binary")

	# Gaussian always uses continuous data even when called for abundance
	if (distribution == "gaussian") {
		is_discrete <- FALSE
	}

	y_int  <- if (is_discrete) as.integer(round(y)) else rep(0, length(y))
	y_cont <- if (!is_discrete) as.numeric(y) else rep(0, length(y))
	
	# Handle edge case where all y are zero
	max_y_val <- if (any(y > 0)) max(y[y > 0]) else 1

	list(
			N = length(y),
			x = as.numeric(x),
			y_int = y_int,
			y_cont = y_cont,
			dist_code = dist_code,
			max_y = max_y_val,
			range_x = diff(range(x)),
			min_x = min(x),
			hp_H = c(2, 3),
			hp_m = c(1, 1),
			hp_s = c(-2.0, 0.6),
			hp_r = c(1.2, 1.2),
			hp_d = c(0.5, 1.0),
			hp_kap = 0.5,
			hp_gamma0 = c(0, 1),
			hp_gamma1 = 0,
			use_r = as.integer(use_r),
			fix_r = fix_r,
			use_d = as.integer(use_d),
			fix_d = fix_d,
			use_p = as.integer(use_p),
			fix_p = fix_p,
			delta = delta
	)
}
