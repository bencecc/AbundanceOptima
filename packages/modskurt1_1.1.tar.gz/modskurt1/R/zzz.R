#' @keywords internal
"_PACKAGE"

.onLoad <- function(libname, pkgname) {
	# Check for cmdstanr availability
	if (!requireNamespace("cmdstanr", quietly = TRUE)) {
		packageStartupMessage(
			"Package 'cmdstanr' is required but not installed.\n",
			"Install it from https://mc-stan.org/cmdstanr/"
		)
	}
}

.onAttach <- function(libname, pkgname) {
	packageStartupMessage(
		"modskurt1: Bayesian Modskurt Abundance-Response Curves\n",
		"Version ", utils::packageVersion("modskurt1"), "\n",
		"Stan model: ", system.file("stan", "modskurt1.stan", package = "modskurt1")
	)
}

#' Get Path to Modskurt Stan Model
#'
#' Returns the file path to the Stan model file installed with the package.
#'
#' @return Character string with the path to modskurt1.stan
#'
#' @examples
#' stan_path <- modskurt_stan_path()
#' # mod <- cmdstanr::cmdstan_model(stan_path)
#'
#' @export
modskurt_stan_path <- function() {
	system.file("stan", "modskurt1.stan", package = "modskurt1")
}
