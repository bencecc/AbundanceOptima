# Function to inizialize parameters to fit modskurt models
###############################################################################

#' Initialize values for modskurt Stan model
#'
#' @param spec A list of data returned by modskurt_spec()
#' @param params Optional list of parameter values (e.g., from modskurt_sim())
#' @return A named list of initial values compatible with Stan
#' @export
modskurt_init <- function(spec, params = NULL) {

	`%||%` <- function(a, b) if (!is.null(a)) a else b

	if (is.null(params)) {
		params <- attr(spec, "params")
	}

	x <- spec$x
	y <- if (spec$dist_code %in% c(1:6, 12:16)) spec$y_int else spec$y_cont
	range_x <- diff(range(x))
	min_x <- min(x)
	max_y <- max(y, na.rm = TRUE)

	list(
					H_raw = if (!is.null(params)) params$H / max_y else rbeta(1, 2, 3),
					m_raw = if (!is.null(params)) (params$m - min_x) / range_x else rbeta(1, 1, 1),
					log_s_raw = if (!is.null(params)) log(params$s / range_x) else rnorm(1, -2.0, 0.6),
					zr_raw = if (spec$use_r == 1) {
								if (!is.null(params)) params$r else rbeta(1, 1.2, 1.2)
							} else NULL,
					log_d_raw = if (spec$use_d == 1) {
								if (!is.null(params)) log(params$d) else rnorm(1, 0.5, 1.0)
							} else NULL,
					zp_raw = if (spec$use_p == 1) {
								if (!is.null(params)) (params$p - 0.05) / 1.95 else rbeta(1, 1.2, 1.2)
							} else NULL,
					k = if (!is.null(params)) params$k else rexp(1, 0.5),
					gamma0 = if (!is.null(params) && !is.null(params$gamma0)) params$gamma0 else rnorm(1, 0, 1),
					gamma1 = if (!is.null(params) && !is.null(params$gamma1)) params$gamma1 else rnorm(1, 0, 1),
					sigma = if (!is.null(params) && !is.null(params$sigma)) params$sigma else abs(rnorm(1, 1, 0.25))
			) |> (\(init) {
					init$zr_raw <- init$zr_raw %||% 0.5
					init$log_d_raw <- init$log_d_raw %||% log(1)
					init$zp_raw <- init$zp_raw %||% 0.5
					init
				})()
}

