#' Sequential palettes (_s) for discrete aesthetics
#' 
#' Use **sequential** palettes (6 chips) derived from cocktail colors for discrete scales.
#' 
#' @param palette pretty name or id (e.g. 'Negroni')
#' @param n number of levels to draw (default 6)
#' @param dir direction (+1 or -1 to reverse)
#' @param start,end numeric in [0,1] to crop palette portion
#' @param ... passed to [ggplot2::discrete_scale()]
#' @param na.value color for NA
#' @export
#' @examples
#' library(ggplot2)
#' ggplot(mtcars, aes(factor(cyl), fill=factor(cyl))) +
#'   geom_bar() +
#'   scale_fill_taster_s(palette='Negroni', n=6, start=0.1, end=1, dir=+1) +
#'   theme_minimal()
scale_color_taster_s <- function(palette, n=6, dir=1, start=0, end=1, ..., na.value=NA){
  rev_if <- function(v) if (dir<0) rev(v) else v
  crop <- function(v){ start<-max(0,min(1,start)); end<-max(0,min(1,end)); if (end<start){tmp<-start; start<-end; end<-tmp}; idx<-unique(round(seq(1,length(v),length.out=max(2,ceiling((end-start)*length(v)))))); v[idx] }
  ggplot2::discrete_scale('colour', paste0('taster_s_', palette), palette=function(n_in){
    nm <- palette; if (!exists(nm, .CockR_envs$seq)) if (exists(nm, .CockR_envs$ids)) nm <- get(nm, .CockR_envs$ids)
    v <- if (exists(nm, .CockR_envs$seq)) get(nm, .CockR_envs$seq) else rlang::abort(paste0('Unknown palette: ', palette))
    v <- crop(v); v <- rev_if(v); if (length(v) >= n) v[seq_len(n)] else .interp_hcl(v, n)
  }, na.value=na.value, ...)
}
#' @rdname scale_color_taster_s
#' @export
scale_fill_taster_s <- function(palette, n=6, dir=1, start=0, end=1, ..., na.value=NA){
  rev_if <- function(v) if (dir<0) rev(v) else v
  crop <- function(v){ start<-max(0,min(1,start)); end<-max(0,min(1,end)); if (end<start){tmp<-start; start<-end; end<-tmp}; idx<-unique(round(seq(1,length(v),length.out=max(2,ceiling((end-start)*length(v)))))); v[idx] }
  ggplot2::discrete_scale('fill', paste0('taster_s_', palette), palette=function(n_in){
    nm <- palette; if (!exists(nm, .CockR_envs$seq)) if (exists(nm, .CockR_envs$ids)) nm <- get(nm, .CockR_envs$ids)
    v <- if (exists(nm, .CockR_envs$seq)) get(nm, .CockR_envs$seq) else rlang::abort(paste0('Unknown palette: ', palette))
    v <- crop(v); v <- rev_if(v); if (length(v) >= n) v[seq_len(n)] else .interp_hcl(v, n)
  }, na.value=na.value, ...)
}
