#' Continuous palettes (_c) for numeric aesthetics
#' 
#' Continuous ramps are built from the corresponding sequential chips (Lab interpolation) for visual consistency.
#' 
#' @param palette pretty name or id
#' @param dir direction (+1 or -1 to reverse)
#' @param start,end numeric in [0,1] to crop palette portion
#' @param ... passed to [ggplot2::scale_*_gradientn()]
#' @param na.value color for NA
#' @export
#' @examples
#' library(ggplot2)
#' ggplot(iris, aes(Sepal.Length, Sepal.Width, color=Petal.Length)) +
#'   geom_point(size=2) +
#'   scale_color_taster_c(palette='Mai Tai', start=0.05, end=0.95, dir=+1) +
#'   theme_minimal()
scale_color_taster_c <- function(palette, dir=1, start=0, end=1, ..., na.value=NA){
  nm <- palette
  if (!exists(nm, .CockR_envs$cont)) {
    idnm <- if (exists(nm, .CockR_envs$ids)) get(nm, .CockR_envs$ids) else nm
    if (!exists(paste0(idnm,'_continuous'), .CockR_envs$cont)) {
      if (exists(idnm, .CockR_envs$seq)) { d <- get(idnm, .CockR_envs$seq); assign(paste0(idnm,'_continuous'), .interp_hcl(d, 256), envir=.CockR_envs$cont) }
    }
    nm <- paste0(idnm,'_continuous')
  }
  cols <- get(nm, .CockR_envs$cont)
  rev_if <- function(v) if (dir<0) rev(v) else v
  start<-max(0,min(1,start)); end<-max(0,min(1,end)); if (end<start){tmp<-start; start<-end; end<-tmp}
  idx <- round(seq(floor(start*length(cols))+1, ceiling(end*length(cols)), length.out=256)); idx <- pmin(pmax(idx,1), length(cols))
  cols <- rev_if(cols[idx])
  ggplot2::scale_color_gradientn(colours=cols, na.value=na.value, ...)
}
#' @rdname scale_color_taster_c
#' @export
#' @examples
#' ggplot(iris, aes(Sepal.Length, Sepal.Width, fill=Petal.Length)) +
#'   geom_tile() +
#'   scale_fill_taster_c(palette='Negroni', start=0, end=1, dir=-1) +
#'   theme_minimal()
scale_fill_taster_c <- function(palette, dir=1, start=0, end=1, ..., na.value=NA){
  nm <- palette
  if (!exists(nm, .CockR_envs$cont)) {
    idnm <- if (exists(nm, .CockR_envs$ids)) get(nm, .CockR_envs$ids) else nm
    if (!exists(paste0(idnm,'_continuous'), .CockR_envs$cont)) {
      if (exists(idnm, .CockR_envs$seq)) { d <- get(idnm, .CockR_envs$seq); assign(paste0(idnm,'_continuous'), .interp_hcl(d, 256), envir=.CockR_envs$cont) }
    }
    nm <- paste0(idnm,'_continuous')
  }
  cols <- get(nm, .CockR_envs$cont)
  rev_if <- function(v) if (dir<0) rev(v) else v
  start<-max(0,min(1,start)); end<-max(0,min(1,end)); if (end<start){tmp<-start; start<-end; end<-tmp}
  idx <- round(seq(floor(start*length(cols))+1, ceiling(end*length(cols)), length.out=256)); idx <- pmin(pmax(idx,1), length(cols))
  cols <- rev_if(cols[idx])
  ggplot2::scale_fill_gradientn(colours=cols, na.value=na.value, ...)
}
