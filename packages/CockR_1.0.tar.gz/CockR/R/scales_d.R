#' Discrete palettes (_d) with optional continuous interpolation
#'
#' Use a **discrete** taster palette as usual for categorical scales, or set
#' `cont = TRUE` to interpolate it for **continuous** data (Lab interpolation).
#' Alternatively, pass a **diverging palette name** (as shown in your swatches PDF)
#' to `cont` (e.g., `cont = "aperol_spritz_blue_lagoon_mimosa"`) to use that
#' diverging ramp directly for continuous data.
#'
#' @param palette Character palette name (in CockR discrete registry) or a hex vector.
#'   Discrete palette names are those you exposed in `.CockR_envs$disc`.
#' @param n Number of levels for discrete scale (ignored when `cont` is used).
#' @param dir +1 keeps order, -1 reverses.
#' @param start,end Portion of the palette to keep (0–1) before applying `n` or interpolation.
#' @param cont FALSE for discrete (default), TRUE to interpolate the discrete palette,
#'   or a **character name of a diverging palette** to use its continuous ramp.
#' @param resolver Optional resolver function(name) -> hex vector (rarely needed).
#' @param ... Passed to the underlying ggplot2 scale.
#' @param na.value Colour for NA.
#' @return A ggplot2 scale.
#' @export
scale_color_taster_d <- function(palette, n = 5, dir = 1, start = 0, end = 1,
                                 cont = FALSE, resolver = NULL, ..., na.value = NA){
  .rev_if <- function(v) if (dir < 0) rev(v) else v
  .crop <- function(v){
    if (!length(v)) return(v)
    s <- max(0, min(1, start)); e <- max(0, min(1, end));
    if (e < s) { tmp <- s; s <- e; e <- tmp }
    i0 <- max(1, floor(s*length(v)) + 1);
    i1 <- min(length(v), ceiling(e*length(v)));
    v[seq.int(i0, i1)]
  }
  .resolve_disc <- function(x){
    if (is.character(x) && length(x) > 1 && all(grepl('^#', x))) return(x)
    if (is.character(x) && length(x) == 1) {
      if (exists(x, .CockR_envs$disc, inherits = FALSE)) return(get(x, .CockR_envs$disc, inherits = FALSE))
      if (!is.null(resolver)) {
        val <- tryCatch(resolver(x), error = function(e) NULL); if (is.character(val)) return(val)
      }
      stop(sprintf("Unknown discrete palette: '%s'", x), call. = FALSE)
    }
    tryCatch(eval.parent(substitute(x)), error = function(e) stop('Could not resolve `palette`.', call. = FALSE))
  }
  .resolve_div <- function(name){
    if (!is.character(name) || length(name) != 1)
      stop('`cont` diverging name must be a single character string.', call. = FALSE)
    if (!exists(name, .CockR_envs$div, inherits = FALSE))
      stop(sprintf("Unknown diverging palette: '%s'", name), call. = FALSE)
    get(name, .CockR_envs$div, inherits = FALSE)
  }

  # If cont is a diverging palette name, use that continuous ramp
  if (is.character(cont) && length(cont) == 1) {
    base <- .resolve_div(cont)
    base <- .crop(base); base <- .rev_if(base)
    cols <- .interp_hcl(base, 256)
    return(ggplot2::scale_color_gradientn(colours = cols, na.value = na.value, ...))
  }

  # Otherwise, resolve the discrete palette
  base <- .resolve_disc(palette)
  base <- .crop(base); base <- .rev_if(base)

  if (isTRUE(cont)) {
    cols <- .interp_hcl(base, 256)
    ggplot2::scale_color_gradientn(colours = cols, na.value = na.value, ...)
  } else {
    pal <- if (length(base) >= n) base[seq_len(n)] else .interp_hcl(base, n)
    ggplot2::discrete_scale(
      aesthetics = 'colour',
      scale_name  = paste0('taster_d_', if (is.character(palette)) palette else 'disc'),
      palette     = function(n_in) pal[seq_len(min(n, length(pal)))],
      na.value    = na.value,
      ...
    )
  }
}

#' @rdname scale_color_taster_d
#' @export
scale_fill_taster_d <- function(palette, n = 5, dir = 1, start = 0, end = 1,
                                cont = FALSE, resolver = NULL, ..., na.value = NA){
  .rev_if <- function(v) if (dir < 0) rev(v) else v
  .crop <- function(v){
    if (!length(v)) return(v)
    s <- max(0, min(1, start)); e <- max(0, min(1, end));
    if (e < s) { tmp <- s; s <- e; e <- tmp }
    i0 <- max(1, floor(s*length(v)) + 1);
    i1 <- min(length(v), ceiling(e*length(v)));
    v[seq.int(i0, i1)]
  }
  .resolve_disc <- function(x){
    if (is.character(x) && length(x) > 1 && all(grepl('^#', x))) return(x)
    if (is.character(x) && length(x) == 1) {
      if (exists(x, .CockR_envs$disc, inherits = FALSE)) return(get(x, .CockR_envs$disc, inherits = FALSE))
      if (!is.null(resolver)) {
        val <- tryCatch(resolver(x), error = function(e) NULL); if (is.character(val)) return(val)
      }
      stop(sprintf("Unknown discrete palette: '%s'", x), call. = FALSE)
    }
    tryCatch(eval.parent(substitute(x)), error = function(e) stop('Could not resolve `palette`.', call. = FALSE))
  }
  .resolve_div <- function(name){
    if (!is.character(name) || length(name) != 1)
      stop('`cont` diverging name must be a single character string.', call. = FALSE)
    if (!exists(name, .CockR_envs$div, inherits = FALSE))
      stop(sprintf("Unknown diverging palette: '%s'", name), call. = FALSE)
    get(name, .CockR_envs$div, inherits = FALSE)
  }

  # If cont is a diverging palette name, use that continuous ramp
  if (is.character(cont) && length(cont) == 1) {
    base <- .resolve_div(cont)
    base <- .crop(base); base <- .rev_if(base)
    cols <- .interp_hcl(base, 256)
    return(ggplot2::scale_fill_gradientn(colours = cols, na.value = na.value, ...))
  }

  # Otherwise, resolve the discrete palette
  base <- .resolve_disc(palette)
  base <- .crop(base); base <- .rev_if(base)

  if (isTRUE(cont)) {
    cols <- .interp_hcl(base, 256)
    ggplot2::scale_fill_gradientn(colours = cols, na.value = na.value, ...)
  } else {
    pal <- if (length(base) >= n) base[seq_len(n)] else .interp_hcl(base, n)
    ggplot2::discrete_scale(
      aesthetics = 'fill',
      scale_name  = paste0('taster_d_', if (is.character(palette)) palette else 'disc'),
      palette     = function(n_in) pal[seq_len(min(n, length(pal)))],
      na.value    = na.value,
      ...
    )
  }
}
