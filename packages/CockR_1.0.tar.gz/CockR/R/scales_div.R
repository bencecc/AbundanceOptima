#' Diverging palettes (_div) for continuous aesthetics
#'
#' Uses a **diverging palette** from the CockR registry (stored as
#' `left (near→out)`, `center`, `right (near→out)`) to build a smooth
#' continuous gradient (Lab interpolation).
#'
#' @param palette Diverging palette name (exactly as in `taster_palettes_diverging()`).
#' @param dir +1 keeps order (left→center→right), -1 reverses.
#' @param start,end Portion of the palette to keep (0–1) before interpolation.
#' @param ... Passed to the underlying `ggplot2::scale_*_gradientn()`.
#' @param na.value Colour for NA values.
#' @return A ggplot2 scale.
#' @export
scale_color_taster_div <- function(palette, dir = 1, start = 0, end = 1, ..., na.value = NA){
  if (!requireNamespace('ggplot2', quietly = TRUE)) stop('ggplot2 is required')
  if (!is.character(palette) || length(palette) != 1)
    stop('`palette` must be a single diverging palette name.', call. = FALSE)
  if (!exists(palette, .CockR_envs$div, inherits = FALSE))
    stop(sprintf("Unknown diverging palette: '%s'", palette), call. = FALSE)
  base <- get(palette, .CockR_envs$div, inherits = FALSE)
  # crop
  s <- max(0, min(1, start)); e <- max(0, min(1, end));
  if (e < s) { tmp <- s; s <- e; e <- tmp }
  i0 <- max(1, floor(s*length(base)) + 1);
  i1 <- min(length(base), ceiling(e*length(base)));
  base <- base[seq.int(i0, i1)]
  # reverse if requested, then Lab interpolation to 256
  if (dir < 0) base <- rev(base)
  cols <- .interp_hcl(base, 256)
  ggplot2::scale_color_gradientn(colours = cols, na.value = na.value, ...)
}

#' @rdname scale_color_taster_div
#' @export
scale_fill_taster_div <- function(palette, dir = 1, start = 0, end = 1, ..., na.value = NA){
  if (!requireNamespace('ggplot2', quietly = TRUE)) stop('ggplot2 is required')
  if (!is.character(palette) || length(palette) != 1)
    stop('`palette` must be a single diverging palette name.', call. = FALSE)
  if (!exists(palette, .CockR_envs$div, inherits = FALSE))
    stop(sprintf("Unknown diverging palette: '%s'", palette), call. = FALSE)
  base <- get(palette, .CockR_envs$div, inherits = FALSE)
  # crop
  s <- max(0, min(1, start)); e <- max(0, min(1, end));
  if (e < s) { tmp <- s; s <- e; e <- tmp }
  i0 <- max(1, floor(s*length(base)) + 1);
  i1 <- min(length(base), ceiling(e*length(base)));
  base <- base[seq.int(i0, i1)]
  # reverse if requested, then Lab interpolation to 256
  if (dir < 0) base <- rev(base)
  cols <- .interp_hcl(base, 256)
  ggplot2::scale_fill_gradientn(colours = cols, na.value = na.value, ...)
}
