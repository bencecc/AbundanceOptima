#' @keywords internal
.CockR_envs <- local({ list(seq=new.env(parent=emptyenv()), cont=new.env(parent=emptyenv()), disc=new.env(parent=emptyenv()), div=new.env(parent=emptyenv()), ids=new.env(parent=emptyenv())) })

#' Perceptually uniform color interpolation using HCL space
#' @param colors character vector of hex colors
#' @param n number of output colors
#' @return character vector of n interpolated hex colors
#' @keywords internal
.interp_hcl <- function(colors, n = 256) {
  if (length(colors) < 2) return(rep(colors, n))
  if (n <= length(colors)) { idx <- round(seq(1, length(colors), length.out = n)); return(colors[idx]) }
  rgb_mat <- grDevices::col2rgb(colors) / 255
  if (requireNamespace('colorspace', quietly = TRUE)) {
    hcl_mat <- t(sapply(seq_len(ncol(rgb_mat)), function(i) { srgb <- colorspace::sRGB(rgb_mat[1, i], rgb_mat[2, i], rgb_mat[3, i]); as(srgb, 'polarLUV')@coords }))
    colnames(hcl_mat) <- c('L', 'C', 'H')
  } else {
    hsv_mat <- grDevices::rgb2hsv(rgb_mat * 255); hcl_mat <- matrix(0, nrow = ncol(rgb_mat), ncol = 3); colnames(hcl_mat) <- c('L', 'C', 'H')
    for (i in seq_len(ncol(rgb_mat))) { hcl_mat[i, 'L'] <- hsv_mat['v', i] * 100; hcl_mat[i, 'C'] <- hsv_mat['s', i] * 100; hcl_mat[i, 'H'] <- hsv_mat['h', i] * 360 }
  }
  H <- hcl_mat[, 'H']; C <- hcl_mat[, 'C']; L <- hcl_mat[, 'L']; chroma_threshold <- 5
  for (i in seq_len(length(H))) { if (is.na(H[i]) || C[i] < chroma_threshold) { chromatic_idx <- which(C >= chroma_threshold & !is.na(H)); if (length(chromatic_idx) > 0) { nearest <- chromatic_idx[which.min(abs(chromatic_idx - i))]; H[i] <- H[nearest] } else { H[i] <- 0 } } }
  x_in <- seq(0, 1, length.out = nrow(hcl_mat)); x_out <- seq(0, 1, length.out = n)
  C_interp <- stats::approx(x_in, C, x_out, rule = 2)$y; L_interp <- stats::approx(x_in, L, x_out, rule = 2)$y
  H_interp <- numeric(n)
  for (i in seq_len(n)) { seg <- findInterval(x_out[i], x_in, all.inside = TRUE); seg <- max(1, min(seg, length(x_in) - 1)); t <- (x_out[i] - x_in[seg]) / (x_in[seg + 1] - x_in[seg]); t <- max(0, min(1, t)); h1 <- H[seg]; h2 <- H[seg + 1]; diff <- h2 - h1; if (abs(diff) > 180) { if (diff > 0) h1 <- h1 + 360 else h2 <- h2 + 360 }; H_interp[i] <- ((1 - t) * h1 + t * h2) %% 360 }
  if (requireNamespace('colorspace', quietly = TRUE)) {
    result <- sapply(seq_len(n), function(i) { hcl_col <- colorspace::polarLUV(L_interp[i], C_interp[i], H_interp[i]); rgb_col <- as(hcl_col, 'sRGB')@coords; rgb_col <- pmax(0, pmin(1, rgb_col)); grDevices::rgb(rgb_col[1], rgb_col[2], rgb_col[3]) })
  } else { result <- grDevices::colorRampPalette(colors, space = 'Lab')(n) }
  result
}

.onLoad <- function(libname, pkgname){
  jp <- system.file('extdata','cockr_taster_palettes.json', package=pkgname); if (!file.exists(jp)) return(invisible())
  dat <- jsonlite::fromJSON(jp)
  for (nm in names(dat$singles$sequential)) assign(nm, dat$singles$sequential[[nm]], envir=.CockR_envs$seq)
  for (nm in names(dat$singles$continuous)) assign(paste0(nm,'_continuous'), dat$singles$continuous[[nm]], envir=.CockR_envs$cont)
  for (nm in names(dat$singles$ids)) { id <- dat$singles$ids[[nm]]; assign(nm, id, envir=.CockR_envs$ids);
    if (nm %in% ls(.CockR_envs$seq)) assign(id, get(nm, .CockR_envs$seq), envir=.CockR_envs$seq)
    if (paste0(nm,'_continuous') %in% ls(.CockR_envs$cont)) assign(paste0(id,'_continuous'), get(paste0(nm,'_continuous'), .CockR_envs$cont), envir=.CockR_envs$cont) }
  if (length(dat$discrete)) for (nm in names(dat$discrete)) assign(nm, dat$discrete[[nm]], envir=.CockR_envs$disc)
  if (length(dat$diverging)) for (nm in names(dat$diverging)) assign(nm, dat$diverging[[nm]], envir=.CockR_envs$div)
}

#' Available single palettes (pretty names)
#' @return character vector of palette names
#' @export
taster_palettes <- function(){ sort(ls(.CockR_envs$seq)) }

#' Mapping of pretty names to machine ids
#' @return named list PrettyName -> machine_id
#' @export
taster_ids <- function(){ as.list(.CockR_envs$ids) }

#' Get a single palette by name
#' @param name pretty name or machine id
#' @return character vector of hex colors
#' @export
taster_palette <- function(name){
  if (exists(name, .CockR_envs$seq)) return(get(name, .CockR_envs$seq))
  if (exists(name, .CockR_envs$cont)) return(get(name, .CockR_envs$cont))
  id <- if (exists(name, .CockR_envs$ids)) get(name, .CockR_envs$ids) else name
  if (exists(id, .CockR_envs$seq)) return(get(id, .CockR_envs$seq))
  if (exists(paste0(id,'_continuous'), .CockR_envs$cont)) return(get(paste0(id,'_continuous'), .CockR_envs$cont))
  rlang::abort(paste0('Unknown palette: ', name))
}

#' Sequential palettes
#' @return named list of hex color vectors (6 colors each)
#' @export
taster_palettes_sequential <- function(){
  nms <- sort(ls(.CockR_envs$seq)); pretty_nms <- nms[!nms %in% unlist(as.list(.CockR_envs$ids))]
  setNames(lapply(pretty_nms, function(n) get(n, .CockR_envs$seq)), pretty_nms)
}

#' Continuous palettes
#' @return named list of hex color vectors (256 colors each)
#' @export
taster_palettes_continuous <- function(){
  nms <- sort(ls(.CockR_envs$cont)); ids_cont <- paste0(unlist(as.list(.CockR_envs$ids)), '_continuous')
  pretty_nms <- nms[!nms %in% ids_cont]
  setNames(lapply(pretty_nms, function(n) get(n, .CockR_envs$cont)), pretty_nms)
}

#' Discrete palettes (combined)
#' @return named list of hex vectors
#' @export
taster_palettes_discrete <- function(){ setNames(lapply(ls(.CockR_envs$disc), function(n) get(n, .CockR_envs$disc)), ls(.CockR_envs$disc)) }

#' Diverging palettes
#' @return named list of hex vectors
#' @export
taster_palettes_diverging <- function(){ setNames(lapply(ls(.CockR_envs$div), function(n) get(n, .CockR_envs$div)), ls(.CockR_envs$div)) }

#' @importFrom grDevices col2rgb rgb
#' @importFrom stats approx
NULL
